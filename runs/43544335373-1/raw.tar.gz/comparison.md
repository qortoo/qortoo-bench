# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-14T02:10:15.228909+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 477.5 | 589.3 | +111.7 | 1.23x | 64.5 | 87.5 |
| GetValue | 2,000,000 | 6.5 | 37.5 | +31.0 | 5.80x | 4.2 | 4.2 |
| Transaction | 20,000 | 2086.8 | 4581.2 | +2494.4 | 2.20x | 432.8 | 955.5 |
| SyncLocal | 20,000 | 29870.9 | 33050.7 | +3179.8 | 1.11x | 1797.8 | 3152.9 |
| BuildCounter | 100 | 64393.9 | 54763.8 | -9630.1 | 0.85x | 18316.7 | 17184.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 946.6 | 3366.5 | +2419.9 | 3.56x | 258.3 | 604.5 |
| Get-64B | 64B | 100,000 | 139.4 | 1563.4 | +1424.0 | 11.22x | 80.1 | 246.9 |
| Transaction-64B | 64B | 400 | 16890.5 | 61540.0 | +44649.4 | 3.64x | 4872.0 | 13972.4 |
| SyncLocal-64B | 64B | 4,000 | 32525.4 | 36848.6 | +4323.1 | 1.13x | 4133.4 | 3957.9 |
| Set-1024B | 1024B | 400 | 2607.4 | 10592.7 | +7985.3 | 4.06x | 1473.4 | 3746.7 |
| Get-1024B | 1024B | 20,000 | 300.4 | 4167.9 | +3867.5 | 13.88x | 147.1 | 941.0 |
| Transaction-1024B | 1024B | 40 | 27031.5 | 135129.8 | +108098.3 | 5.00x | 15677.9 | 52143.2 |
| SyncLocal-1024B | 1024B | 400 | 29318.8 | 52123.7 | +22804.9 | 1.78x | 10906.9 | 15335.5 |
| Set-16384B | 16384B | 40 | 29771.5 | 136009.0 | +106237.5 | 4.57x | 23492.6 | 48593.9 |
| Get-16384B | 16384B | 2,000 | 3028.3 | 66267.0 | +63238.8 | 21.88x | 1869.4 | 17279.6 |
| Transaction-16384B | 16384B | 4 | 567469.8 | 1864383.9 | +1296914.1 | 3.29x | 219386.0 | 488440.3 |
| SyncLocal-16384B | 16384B | 40 | 90064.5 | 198484.7 | +108420.1 | 2.20x | 43890.6 | 57749.6 |

