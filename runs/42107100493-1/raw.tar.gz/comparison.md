# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-05T20:55:08.478714+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 384.1 | 533.5 | +149.4 | 1.39x | 55.9 | 89.3 |
| GetValue | 2,000,000 | 5.4 | 36.9 | +31.5 | 6.84x | 2.6 | 4.0 |
| Transaction | 20,000 | 2132.9 | 4556.3 | +2423.4 | 2.14x | 468.7 | 802.5 |
| SyncLocal | 20,000 | 27189.4 | 31542.9 | +4353.4 | 1.16x | 850.6 | 5690.0 |
| BuildCounter | 100 | 61417.7 | 49906.0 | -11511.7 | 0.81x | 24081.2 | 24881.9 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 910.4 | 3289.2 | +2378.8 | 3.61x | 288.1 | 870.9 |
| Get-64B | 64B | 100,000 | 133.2 | 1245.4 | +1112.2 | 9.35x | 51.8 | 373.6 |
| Transaction-64B | 64B | 400 | 6885.4 | 33397.1 | +26511.7 | 4.85x | 3102.3 | 13338.0 |
| SyncLocal-64B | 64B | 4,000 | 27155.7 | 31453.6 | +4297.8 | 1.16x | 3942.7 | 3006.1 |
| Set-1024B | 1024B | 400 | 2498.6 | 9654.5 | +7155.9 | 3.86x | 838.2 | 3983.2 |
| Get-1024B | 1024B | 20,000 | 285.2 | 4079.1 | +3793.9 | 14.30x | 90.5 | 467.0 |
| Transaction-1024B | 1024B | 40 | 23066.0 | 133868.6 | +110802.6 | 5.80x | 11671.8 | 37879.6 |
| SyncLocal-1024B | 1024B | 400 | 32672.7 | 50992.6 | +18319.9 | 1.56x | 8225.3 | 14435.6 |
| Set-16384B | 16384B | 40 | 27671.6 | 114443.6 | +86771.9 | 4.14x | 11607.9 | 46024.0 |
| Get-16384B | 16384B | 2,000 | 2964.4 | 53965.1 | +51000.8 | 18.20x | 1529.8 | 9835.1 |
| Transaction-16384B | 16384B | 4 | 358048.1 | 1562948.2 | +1204900.1 | 4.37x | 428052.4 | 1373856.1 |
| SyncLocal-16384B | 16384B | 40 | 66851.0 | 159917.5 | +93066.5 | 2.39x | 42276.7 | 52769.6 |

