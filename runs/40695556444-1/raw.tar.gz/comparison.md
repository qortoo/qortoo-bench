# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-28T13:25:10.779420+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 486.0 | 614.1 | +128.1 | 1.26x | 104.5 | 196.6 |
| GetValue | 2,000,000 | 7.9 | 49.1 | +41.3 | 6.25x | 2.0 | 7.2 |
| Transaction | 20,000 | 2653.9 | 5035.1 | +2381.2 | 1.90x | 427.3 | 597.1 |
| SyncLocal | 20,000 | 42792.3 | 46479.5 | +3687.2 | 1.09x | 9156.6 | 9413.4 |
| BuildCounter | 100 | 84992.1 | 74716.6 | -10275.5 | 0.88x | 20415.0 | 20820.8 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1369.8 | 3700.8 | +2331.0 | 2.70x | 509.0 | 786.0 |
| Get-64B | 64B | 100,000 | 176.7 | 1600.1 | +1423.4 | 9.05x | 30.6 | 181.6 |
| Transaction-64B | 64B | 400 | 7230.0 | 40563.1 | +33333.1 | 5.61x | 3685.2 | 8755.8 |
| SyncLocal-64B | 64B | 4,000 | 40798.8 | 46934.6 | +6135.8 | 1.15x | 11225.8 | 16803.4 |
| Set-1024B | 1024B | 400 | 2314.2 | 9486.6 | +7172.4 | 4.10x | 1522.7 | 8942.0 |
| Get-1024B | 1024B | 20,000 | 368.7 | 6016.5 | +5647.8 | 16.32x | 81.8 | 1287.2 |
| Transaction-1024B | 1024B | 40 | 21663.2 | 128326.2 | +106663.0 | 5.92x | 12969.1 | 86737.4 |
| SyncLocal-1024B | 1024B | 400 | 40388.2 | 53338.3 | +12950.2 | 1.32x | 14631.4 | 19626.1 |
| Set-16384B | 16384B | 40 | 27121.2 | 138065.8 | +110944.6 | 5.09x | 17485.9 | 36651.6 |
| Get-16384B | 16384B | 2,000 | 4334.7 | 58239.8 | +53905.2 | 13.44x | 995.2 | 17982.8 |
| Transaction-16384B | 16384B | 4 | 291859.8 | 1291632.1 | +999772.4 | 4.43x | 161448.5 | 330347.9 |
| SyncLocal-16384B | 16384B | 40 | 67868.7 | 158994.6 | +91125.9 | 2.34x | 39762.6 | 147961.5 |

