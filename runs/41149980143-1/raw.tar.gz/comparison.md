# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-31T00:28:49.996197+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 494.7 | 631.4 | +136.7 | 1.28x | 167.4 | 220.9 |
| GetValue | 2,000,000 | 11.5 | 47.5 | +36.0 | 4.13x | 3.6 | 11.1 |
| Transaction | 20,000 | 4079.4 | 7499.0 | +3419.5 | 1.84x | 1030.4 | 1091.5 |
| SyncLocal | 20,000 | 32117.7 | 34696.3 | +2578.7 | 1.08x | 8366.8 | 7000.2 |
| BuildCounter | 100 | 55657.5 | 53887.2 | -1770.3 | 0.97x | 26768.7 | 41687.2 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 910.9 | 4470.1 | +3559.2 | 4.91x | 1243.4 | 1952.3 |
| Get-64B | 64B | 100,000 | 312.6 | 2205.5 | +1892.9 | 7.05x | 92.5 | 216.0 |
| Transaction-64B | 64B | 400 | 16503.9 | 62641.9 | +46138.0 | 3.80x | 4549.6 | 13120.4 |
| SyncLocal-64B | 64B | 4,000 | 40991.2 | 47179.9 | +6188.7 | 1.15x | 7278.1 | 21364.2 |
| Set-1024B | 1024B | 400 | 3443.0 | 9522.2 | +6079.2 | 2.77x | 2690.4 | 6828.4 |
| Get-1024B | 1024B | 20,000 | 553.4 | 6638.3 | +6084.9 | 12.00x | 204.3 | 760.5 |
| Transaction-1024B | 1024B | 40 | 47175.7 | 171464.9 | +124289.2 | 3.63x | 33470.3 | 55868.3 |
| SyncLocal-1024B | 1024B | 400 | 45706.9 | 55628.7 | +9921.8 | 1.22x | 15204.7 | 14003.2 |
| Set-16384B | 16384B | 40 | 58285.9 | 207843.5 | +149557.6 | 3.57x | 13824.1 | 49072.8 |
| Get-16384B | 16384B | 2,000 | 6214.5 | 73041.9 | +66827.4 | 11.75x | 1833.7 | 10471.0 |
| Transaction-16384B | 16384B | 4 | 666725.6 | 1821949.9 | +1155224.2 | 2.73x | 259849.9 | 558830.1 |
| SyncLocal-16384B | 16384B | 40 | 104236.1 | 219218.4 | +114982.3 | 2.10x | 29505.0 | 69091.4 |

