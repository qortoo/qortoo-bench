# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T12:25:49.675226+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 397.8 | 528.4 | +130.6 | 1.33x | 50.3 | 55.7 |
| GetValue | 2,000,000 | 9.4 | 43.6 | +34.2 | 4.63x | 4.0 | 5.6 |
| Transaction | 20,000 | 2205.6 | 5022.1 | +2816.5 | 2.28x | 982.1 | 1154.0 |
| SyncLocal | 20,000 | 28445.4 | 34171.5 | +5726.1 | 1.20x | 2841.5 | 7676.4 |
| BuildCounter | 100 | 52949.3 | 46668.4 | -6280.9 | 0.88x | 12811.7 | 35007.7 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 872.7 | 3076.0 | +2203.3 | 3.52x | 419.9 | 680.3 |
| Get-64B | 64B | 100,000 | 136.2 | 1543.0 | +1406.8 | 11.33x | 66.6 | 313.7 |
| Transaction-64B | 64B | 400 | 7007.2 | 46068.6 | +39061.4 | 6.57x | 5019.1 | 18200.4 |
| SyncLocal-64B | 64B | 4,000 | 28916.7 | 35006.3 | +6089.7 | 1.21x | 7526.6 | 5495.4 |
| Set-1024B | 1024B | 400 | 2531.6 | 13788.6 | +11257.0 | 5.45x | 1685.7 | 5024.9 |
| Get-1024B | 1024B | 20,000 | 284.3 | 5054.9 | +4770.6 | 17.78x | 118.5 | 972.0 |
| Transaction-1024B | 1024B | 40 | 25099.3 | 99455.6 | +74356.3 | 3.96x | 16699.4 | 49595.6 |
| SyncLocal-1024B | 1024B | 400 | 23196.1 | 51245.0 | +28048.8 | 2.21x | 7973.3 | 15113.1 |
| Set-16384B | 16384B | 40 | 26386.1 | 93474.7 | +67088.6 | 3.54x | 11502.9 | 45208.7 |
| Get-16384B | 16384B | 2,000 | 2754.0 | 55535.2 | +52781.2 | 20.17x | 1660.3 | 10681.0 |
| Transaction-16384B | 16384B | 4 | 288656.0 | 1170276.1 | +881620.1 | 4.05x | 148522.2 | 485138.7 |
| SyncLocal-16384B | 16384B | 40 | 57164.0 | 178839.6 | +121675.6 | 3.13x | 31170.0 | 91834.7 |

