# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-18T21:06:42.742193+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 321.4 | 421.2 | +99.7 | 1.31x | 6.0 | 35.9 |
| GetValue | 2,000,000 | 4.2 | 28.4 | +24.2 | 6.75x | 0.0 | 1.8 |
| Transaction | 20,000 | 1733.9 | 3195.0 | +1461.1 | 1.84x | 59.6 | 149.8 |
| SyncLocal | 20,000 | 16801.0 | 17868.8 | +1067.8 | 1.06x | 1349.3 | 922.0 |
| BuildCounter | 100 | 37354.8 | 32371.3 | -4983.5 | 0.87x | 2338.5 | 2460.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 692.3 | 2362.0 | +1669.7 | 3.41x | 29.7 | 142.9 |
| Get-64B | 64B | 100,000 | 102.3 | 792.9 | +690.6 | 7.75x | 1.1 | 19.3 |
| Transaction-64B | 64B | 400 | 5322.0 | 23875.8 | +18553.8 | 4.49x | 113.1 | 1849.0 |
| SyncLocal-64B | 64B | 4,000 | 13699.5 | 17934.6 | +4235.1 | 1.31x | 1711.4 | 2597.3 |
| Set-1024B | 1024B | 400 | 1788.0 | 7336.6 | +5548.6 | 4.10x | 115.0 | 607.2 |
| Get-1024B | 1024B | 20,000 | 223.2 | 2595.2 | +2372.0 | 11.63x | 39.2 | 230.5 |
| Transaction-1024B | 1024B | 40 | 16879.2 | 76959.2 | +60080.0 | 4.56x | 962.1 | 8611.2 |
| SyncLocal-1024B | 1024B | 400 | 14597.4 | 20279.0 | +5681.6 | 1.39x | 1101.7 | 1691.5 |
| Set-16384B | 16384B | 40 | 19515.7 | 70096.0 | +50580.4 | 3.59x | 988.3 | 6150.8 |
| Get-16384B | 16384B | 2,000 | 2400.2 | 26960.8 | +24560.5 | 11.23x | 19.6 | 631.4 |
| Transaction-16384B | 16384B | 4 | 210878.9 | 729356.0 | +518477.1 | 3.46x | 6287.5 | 63749.4 |
| SyncLocal-16384B | 16384B | 40 | 31801.0 | 89306.0 | +57505.0 | 2.81x | 4652.0 | 8698.7 |

