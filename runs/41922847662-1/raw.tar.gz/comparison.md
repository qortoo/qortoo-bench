# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-04T22:14:40.901471+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 407.5 | 531.4 | +123.9 | 1.30x | 44.4 | 59.9 |
| GetValue | 2,000,000 | 5.4 | 37.5 | +32.1 | 6.91x | 3.5 | 2.1 |
| Transaction | 20,000 | 2376.2 | 4065.1 | +1688.9 | 1.71x | 686.5 | 696.7 |
| SyncLocal | 20,000 | 28017.1 | 35630.7 | +7613.6 | 1.27x | 1434.4 | 6388.9 |
| BuildCounter | 100 | 72859.8 | 53908.5 | -18951.3 | 0.74x | 19005.5 | 18159.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 925.2 | 3461.9 | +2536.7 | 3.74x | 75.5 | 851.0 |
| Get-64B | 64B | 100,000 | 131.8 | 1399.8 | +1268.0 | 10.62x | 50.9 | 266.9 |
| Transaction-64B | 64B | 400 | 7862.7 | 35861.3 | +27998.5 | 4.56x | 4576.9 | 8248.0 |
| SyncLocal-64B | 64B | 4,000 | 26793.5 | 34407.9 | +7614.3 | 1.28x | 3842.2 | 10384.3 |
| Set-1024B | 1024B | 400 | 2685.2 | 10634.9 | +7949.6 | 3.96x | 703.6 | 5335.5 |
| Get-1024B | 1024B | 20,000 | 296.2 | 4885.8 | +4589.7 | 16.50x | 126.5 | 1034.4 |
| Transaction-1024B | 1024B | 40 | 25911.4 | 164732.3 | +138820.9 | 6.36x | 9918.7 | 58145.5 |
| SyncLocal-1024B | 1024B | 400 | 23914.4 | 42473.0 | +18558.6 | 1.78x | 7463.8 | 9761.9 |
| Set-16384B | 16384B | 40 | 29688.8 | 125699.1 | +96010.3 | 4.23x | 2511.7 | 80607.2 |
| Get-16384B | 16384B | 2,000 | 2936.6 | 43483.8 | +40547.2 | 14.81x | 1099.7 | 10990.7 |
| Transaction-16384B | 16384B | 4 | 313455.4 | 1045067.6 | +731612.2 | 3.33x | 86473.9 | 330068.6 |
| SyncLocal-16384B | 16384B | 40 | 60283.8 | 137002.7 | +76718.9 | 2.27x | 15739.2 | 34431.9 |

