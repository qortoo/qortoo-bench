# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T11:59:31.597545+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 446.6 | 521.2 | +74.6 | 1.17x | 52.6 | 54.0 |
| GetValue | 2,000,000 | 5.6 | 40.9 | +35.3 | 7.35x | 2.6 | 4.4 |
| Transaction | 20,000 | 2129.9 | 4147.1 | +2017.2 | 1.95x | 273.9 | 758.0 |
| SyncLocal | 20,000 | 29869.3 | 34235.1 | +4365.8 | 1.15x | 3343.8 | 4890.7 |
| BuildCounter | 100 | 61432.5 | 45867.9 | -15564.6 | 0.75x | 14586.8 | 19413.4 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 870.1 | 3618.6 | +2748.5 | 4.16x | 156.5 | 1103.3 |
| Get-64B | 64B | 100,000 | 130.0 | 1459.7 | +1329.7 | 11.22x | 50.3 | 227.0 |
| Transaction-64B | 64B | 400 | 6735.7 | 31807.5 | +25071.8 | 4.72x | 5411.8 | 13652.8 |
| SyncLocal-64B | 64B | 4,000 | 30467.5 | 33786.4 | +3318.9 | 1.11x | 4016.5 | 8333.8 |
| Set-1024B | 1024B | 400 | 2280.6 | 11239.4 | +8958.8 | 4.93x | 1389.1 | 5003.9 |
| Get-1024B | 1024B | 20,000 | 295.5 | 5199.8 | +4904.4 | 17.60x | 230.3 | 1000.7 |
| Transaction-1024B | 1024B | 40 | 26750.4 | 149825.6 | +123075.2 | 5.60x | 14707.8 | 45243.6 |
| SyncLocal-1024B | 1024B | 400 | 32835.3 | 44979.3 | +12144.0 | 1.37x | 17984.7 | 7973.8 |
| Set-16384B | 16384B | 40 | 31506.6 | 97726.6 | +66220.0 | 3.10x | 15282.6 | 31080.4 |
| Get-16384B | 16384B | 2,000 | 2834.6 | 51900.1 | +49065.5 | 18.31x | 1048.7 | 9395.8 |
| Transaction-16384B | 16384B | 4 | 277921.0 | 1667009.4 | +1389088.4 | 6.00x | 191513.6 | 444587.3 |
| SyncLocal-16384B | 16384B | 40 | 61866.9 | 187339.8 | +125472.9 | 3.03x | 22295.3 | 37969.7 |

