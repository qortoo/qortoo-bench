# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-18T09:40:17.105958+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `83062e961c74299a60061b2b1f6b98ad492c9d4b` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 370.9 | 490.5 | +119.5 | 1.32x | 19.9 | 23.4 |
| GetValue | 2,000,000 | 5.5 | 36.6 | +31.2 | 6.69x | 0.0 | 0.6 |
| Transaction | 20,000 | 2342.0 | 4123.4 | +1781.5 | 1.76x | 59.4 | 132.5 |
| SyncLocal | 20,000 | 23875.7 | 24431.3 | +555.6 | 1.02x | 924.7 | 329.0 |
| BuildCounter | 100 | 42023.3 | 39123.1 | -2900.3 | 0.93x | 818.7 | 1186.1 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 816.9 | 3009.8 | +2192.9 | 3.68x | 16.6 | 60.9 |
| Get-64B | 64B | 100,000 | 118.3 | 995.3 | +876.9 | 8.41x | 1.2 | 12.5 |
| Transaction-64B | 64B | 400 | 6990.7 | 29442.8 | +22452.1 | 4.21x | 154.0 | 273.7 |
| SyncLocal-64B | 64B | 4,000 | 21551.3 | 25329.7 | +3778.4 | 1.18x | 1555.3 | 1333.5 |
| Set-1024B | 1024B | 400 | 2147.0 | 8514.6 | +6367.6 | 3.97x | 41.6 | 298.3 |
| Get-1024B | 1024B | 20,000 | 271.3 | 3156.1 | +2884.8 | 11.63x | 1.6 | 59.5 |
| Transaction-1024B | 1024B | 40 | 21145.9 | 88020.1 | +66874.2 | 4.16x | 593.1 | 3287.8 |
| SyncLocal-1024B | 1024B | 400 | 20759.5 | 28282.1 | +7522.6 | 1.36x | 539.7 | 656.3 |
| Set-16384B | 16384B | 40 | 23507.6 | 80092.3 | +56584.7 | 3.41x | 381.0 | 5134.4 |
| Get-16384B | 16384B | 2,000 | 2883.8 | 32706.3 | +29822.5 | 11.34x | 27.0 | 505.2 |
| Transaction-16384B | 16384B | 4 | 251097.1 | 861032.8 | +609935.6 | 3.43x | 7755.1 | 26625.7 |
| SyncLocal-16384B | 16384B | 40 | 54595.7 | 112382.9 | +57787.2 | 2.06x | 492.4 | 2825.9 |

