# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T18:55:11.568019+00:00
- **Platform**: `Linux-7.0.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `47ba481c27c4f09022ca3a07b6794ddafeef0fca` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 424.3 | 518.7 | +94.4 | 1.22x | 13.1 | 25.2 |
| GetValue | 2,000,000 | 10.5 | 36.8 | +26.3 | 3.51x | 0.2 | 2.7 |
| Transaction | 20,000 | 2080.2 | 3378.1 | +1297.9 | 1.62x | 36.2 | 109.0 |
| SyncLocal | 20,000 | 17268.2 | 18688.1 | +1419.8 | 1.08x | 1818.9 | 650.2 |
| BuildCounter | 100 | 36712.9 | 31806.5 | -4906.3 | 0.87x | 854.2 | 1084.3 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 792.7 | 2714.9 | +1922.2 | 3.42x | 15.1 | 46.7 |
| Get-64B | 64B | 100,000 | 114.2 | 799.4 | +685.2 | 7.00x | 1.5 | 14.0 |
| Transaction-64B | 64B | 400 | 5752.0 | 26130.5 | +20378.5 | 4.54x | 99.9 | 559.8 |
| SyncLocal-64B | 64B | 4,000 | 17502.8 | 20059.8 | +2557.0 | 1.15x | 496.3 | 656.6 |
| Set-1024B | 1024B | 400 | 1691.5 | 9001.0 | +7309.5 | 5.32x | 31.2 | 396.4 |
| Get-1024B | 1024B | 20,000 | 226.3 | 2541.2 | +2314.8 | 11.23x | 2.6 | 27.1 |
| Transaction-1024B | 1024B | 40 | 15812.4 | 93184.8 | +77372.4 | 5.89x | 469.6 | 2967.1 |
| SyncLocal-1024B | 1024B | 400 | 18584.1 | 26106.2 | +7522.1 | 1.40x | 683.4 | 520.6 |
| Set-16384B | 16384B | 40 | 16617.9 | 74272.9 | +57655.0 | 4.47x | 337.4 | 2862.1 |
| Get-16384B | 16384B | 2,000 | 2088.8 | 24208.4 | +22119.6 | 11.59x | 28.9 | 622.4 |
| Transaction-16384B | 16384B | 4 | 182593.8 | 834850.6 | +652256.9 | 4.57x | 4857.8 | 40048.0 |
| SyncLocal-16384B | 16384B | 40 | 35183.2 | 91076.4 | +55893.2 | 2.59x | 644.4 | 3492.8 |

