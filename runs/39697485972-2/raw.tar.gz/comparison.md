# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T00:15:03.122587+00:00
- **Platform**: `Linux-7.0.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `dda1d35d8b12e8d3d6310079c3bbf8dfa4e1a7b5` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 494.2 | 672.1 | +177.9 | 1.36x | 6.6 | 44.5 |
| GetValue | 2,000,000 | 7.0 | 47.6 | +40.6 | 6.79x | 0.0 | 0.6 |
| Transaction | 20,000 | 2716.1 | 4951.2 | +2235.1 | 1.82x | 42.9 | 126.1 |
| SyncLocal | 20,000 | 24718.7 | 26524.1 | +1805.4 | 1.07x | 381.1 | 632.9 |
| BuildCounter | 100 | 52581.0 | 48403.3 | -4177.7 | 0.92x | 2342.6 | 1086.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1071.7 | 4246.9 | +3175.2 | 3.96x | 16.2 | 67.0 |
| Get-64B | 64B | 100,000 | 165.1 | 1331.4 | +1166.3 | 8.06x | 3.1 | 16.3 |
| Transaction-64B | 64B | 400 | 8644.4 | 42558.8 | +33914.4 | 4.92x | 495.5 | 670.6 |
| SyncLocal-64B | 64B | 4,000 | 23076.0 | 28218.1 | +5142.0 | 1.22x | 845.6 | 3441.0 |
| Set-1024B | 1024B | 400 | 2798.5 | 14626.8 | +11828.3 | 5.23x | 54.8 | 236.9 |
| Get-1024B | 1024B | 20,000 | 357.8 | 4294.5 | +3936.7 | 12.00x | 2.5 | 140.0 |
| Transaction-1024B | 1024B | 40 | 27081.9 | 151248.7 | +124166.8 | 5.58x | 946.3 | 4994.9 |
| SyncLocal-1024B | 1024B | 400 | 25085.5 | 38016.5 | +12930.9 | 1.52x | 531.5 | 199.9 |
| Set-16384B | 16384B | 40 | 30616.3 | 127013.0 | +96396.7 | 4.15x | 1036.1 | 3968.3 |
| Get-16384B | 16384B | 2,000 | 3596.3 | 43301.8 | +39705.5 | 12.04x | 76.1 | 976.7 |
| Transaction-16384B | 16384B | 4 | 328094.2 | 1380719.4 | +1052625.1 | 4.21x | 7287.3 | 32970.6 |
| SyncLocal-16384B | 16384B | 40 | 58170.1 | 155580.3 | +97410.2 | 2.67x | 763.3 | 6787.4 |

