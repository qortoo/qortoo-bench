# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T12:24:55.129642+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 387.3 | 526.4 | +139.2 | 1.36x | 52.9 | 120.5 |
| GetValue | 2,000,000 | 5.7 | 37.0 | +31.3 | 6.54x | 3.7 | 6.6 |
| Transaction | 20,000 | 2473.3 | 4515.9 | +2042.6 | 1.83x | 878.1 | 1220.3 |
| SyncLocal | 20,000 | 28559.0 | 34356.9 | +5797.9 | 1.20x | 5438.1 | 7965.9 |
| BuildCounter | 100 | 87971.9 | 59828.5 | -28143.4 | 0.68x | 19897.0 | 17857.1 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 884.9 | 3596.4 | +2711.5 | 4.06x | 275.0 | 1430.7 |
| Get-64B | 64B | 100,000 | 130.7 | 1391.3 | +1260.6 | 10.65x | 36.6 | 249.9 |
| Transaction-64B | 64B | 400 | 6770.1 | 34174.3 | +27404.2 | 5.05x | 3570.6 | 16668.9 |
| SyncLocal-64B | 64B | 4,000 | 28004.4 | 33150.8 | +5146.5 | 1.18x | 7570.5 | 9647.0 |
| Set-1024B | 1024B | 400 | 2249.7 | 9762.3 | +7512.5 | 4.34x | 1472.7 | 5255.2 |
| Get-1024B | 1024B | 20,000 | 287.0 | 5247.4 | +4960.4 | 18.28x | 219.3 | 1185.4 |
| Transaction-1024B | 1024B | 40 | 21830.8 | 112399.5 | +90568.7 | 5.15x | 12114.2 | 51462.9 |
| SyncLocal-1024B | 1024B | 400 | 25669.0 | 39234.4 | +13565.5 | 1.53x | 21214.7 | 13345.9 |
| Set-16384B | 16384B | 40 | 27099.9 | 93159.6 | +66059.8 | 3.44x | 14582.7 | 56179.3 |
| Get-16384B | 16384B | 2,000 | 2836.6 | 60941.6 | +58105.0 | 21.48x | 1980.8 | 13848.4 |
| Transaction-16384B | 16384B | 4 | 276170.0 | 1558536.8 | +1282366.8 | 5.64x | 158151.5 | 655725.0 |
| SyncLocal-16384B | 16384B | 40 | 58933.5 | 158438.6 | +99505.1 | 2.69x | 31582.3 | 66943.5 |

