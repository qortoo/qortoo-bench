# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T12:25:58.006077+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 479.6 | 620.4 | +140.9 | 1.29x | 108.0 | 114.0 |
| GetValue | 2,000,000 | 10.4 | 52.0 | +41.6 | 4.98x | 3.1 | 10.1 |
| Transaction | 20,000 | 2900.5 | 5049.0 | +2148.5 | 1.74x | 542.3 | 921.3 |
| SyncLocal | 20,000 | 43935.8 | 51451.4 | +7515.5 | 1.17x | 5275.9 | 5837.8 |
| BuildCounter | 100 | 62252.9 | 60607.7 | -1645.2 | 0.97x | 24930.3 | 15840.7 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 884.8 | 4739.0 | +3854.1 | 5.36x | 375.6 | 1358.7 |
| Get-64B | 64B | 100,000 | 183.1 | 1607.9 | +1424.9 | 8.78x | 39.5 | 187.0 |
| Transaction-64B | 64B | 400 | 10421.6 | 41585.8 | +31164.3 | 3.99x | 5497.4 | 7025.0 |
| SyncLocal-64B | 64B | 4,000 | 43204.7 | 48240.7 | +5036.0 | 1.12x | 5402.9 | 7035.9 |
| Set-1024B | 1024B | 400 | 2363.9 | 10337.3 | +7973.5 | 4.37x | 3386.4 | 6502.7 |
| Get-1024B | 1024B | 20,000 | 483.9 | 5544.8 | +5061.0 | 11.46x | 113.3 | 441.6 |
| Transaction-1024B | 1024B | 40 | 22137.3 | 122216.6 | +100079.4 | 5.52x | 5476.6 | 53453.0 |
| SyncLocal-1024B | 1024B | 400 | 38374.0 | 48414.6 | +10040.5 | 1.26x | 15558.9 | 6466.9 |
| Set-16384B | 16384B | 40 | 26453.3 | 133536.5 | +107083.2 | 5.05x | 17998.3 | 57536.5 |
| Get-16384B | 16384B | 2,000 | 3856.2 | 55124.3 | +51268.1 | 14.29x | 1600.7 | 6603.7 |
| Transaction-16384B | 16384B | 4 | 296171.6 | 1465169.4 | +1168997.8 | 4.95x | 183341.1 | 611675.2 |
| SyncLocal-16384B | 16384B | 40 | 77497.4 | 158117.1 | +80619.7 | 2.04x | 23807.4 | 98777.5 |

