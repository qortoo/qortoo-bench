# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-21T22:16:47.158982+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `e849a4eff55bc1cb03b28b5a5078f4ae73d85015` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 413.2 | 561.2 | +148.0 | 1.36x | 7.2 | 52.5 |
| GetValue | 2,000,000 | 6.8 | 41.4 | +34.7 | 6.13x | 0.4 | 1.1 |
| Transaction | 20,000 | 2379.7 | 4682.0 | +2302.2 | 1.97x | 20.5 | 134.9 |
| SyncLocal | 20,000 | 36928.0 | 39537.6 | +2609.7 | 1.07x | 1902.0 | 850.3 |
| BuildCounter | 100 | 60268.2 | 57333.1 | -2935.1 | 0.95x | 879.3 | 1064.1 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 988.8 | 4062.2 | +3073.4 | 4.11x | 9.5 | 144.3 |
| Get-64B | 64B | 100,000 | 146.4 | 1349.9 | +1203.5 | 9.22x | 0.9 | 9.3 |
| Transaction-64B | 64B | 400 | 8194.9 | 40544.1 | +32349.1 | 4.95x | 160.6 | 1067.4 |
| SyncLocal-64B | 64B | 4,000 | 28752.2 | 39405.8 | +10653.6 | 1.37x | 1314.1 | 3095.9 |
| Set-1024B | 1024B | 400 | 2411.0 | 12151.9 | +9740.9 | 5.04x | 84.8 | 646.5 |
| Get-1024B | 1024B | 20,000 | 341.4 | 4006.4 | +3665.0 | 11.74x | 4.8 | 56.1 |
| Transaction-1024B | 1024B | 40 | 23220.8 | 131663.8 | +108443.0 | 5.67x | 454.1 | 6618.2 |
| SyncLocal-1024B | 1024B | 400 | 25137.4 | 41202.8 | +16065.4 | 1.64x | 899.2 | 1842.7 |
| Set-16384B | 16384B | 40 | 25899.9 | 111731.8 | +85831.9 | 4.31x | 1239.6 | 5103.0 |
| Get-16384B | 16384B | 2,000 | 3222.6 | 39741.2 | +36518.6 | 12.33x | 1420.7 | 1009.0 |
| Transaction-16384B | 16384B | 4 | 292218.5 | 1226368.2 | +934149.8 | 4.20x | 9477.9 | 48797.2 |
| SyncLocal-16384B | 16384B | 40 | 55486.9 | 154158.3 | +98671.4 | 2.78x | 848.2 | 5130.4 |

