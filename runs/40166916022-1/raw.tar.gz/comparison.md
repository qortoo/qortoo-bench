# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-25T05:53:21.313688+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 390.5 | 484.7 | +94.2 | 1.24x | 32.3 | 44.0 |
| GetValue | 2,000,000 | 5.5 | 36.6 | +31.1 | 6.62x | 2.8 | 3.7 |
| Transaction | 20,000 | 2204.3 | 3871.9 | +1667.6 | 1.76x | 546.6 | 1330.7 |
| SyncLocal | 20,000 | 27288.0 | 41910.1 | +14622.1 | 1.54x | 2755.4 | 8470.0 |
| BuildCounter | 100 | 61721.1 | 46324.6 | -15396.6 | 0.75x | 14399.7 | 19367.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 873.7 | 3206.8 | +2333.1 | 3.67x | 377.3 | 1002.3 |
| Get-64B | 64B | 100,000 | 131.1 | 1412.1 | +1280.9 | 10.77x | 25.7 | 290.1 |
| Transaction-64B | 64B | 400 | 7010.9 | 35584.4 | +28573.5 | 5.08x | 3608.8 | 10970.8 |
| SyncLocal-64B | 64B | 4,000 | 25100.4 | 33783.4 | +8683.0 | 1.35x | 5876.8 | 3996.6 |
| Set-1024B | 1024B | 400 | 2263.5 | 11292.8 | +9029.3 | 4.99x | 1461.2 | 4630.8 |
| Get-1024B | 1024B | 20,000 | 293.2 | 4868.3 | +4575.1 | 16.61x | 125.4 | 349.6 |
| Transaction-1024B | 1024B | 40 | 22626.4 | 142274.3 | +119647.9 | 6.29x | 11082.4 | 45730.3 |
| SyncLocal-1024B | 1024B | 400 | 21177.9 | 44137.1 | +22959.2 | 2.08x | 8753.3 | 9526.7 |
| Set-16384B | 16384B | 40 | 26390.6 | 94090.8 | +67700.2 | 3.57x | 17324.8 | 40380.7 |
| Get-16384B | 16384B | 2,000 | 2778.3 | 57422.0 | +54643.7 | 20.67x | 1461.1 | 7959.3 |
| Transaction-16384B | 16384B | 4 | 289385.0 | 1283477.0 | +994092.0 | 4.44x | 113699.4 | 481684.8 |
| SyncLocal-16384B | 16384B | 40 | 55849.8 | 172372.6 | +116522.8 | 3.09x | 18670.4 | 71158.6 |

