# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-24T02:39:32.422954+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `7d0830cc9b2f99d6348b4f3f45d61f9db94a199c` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 407.5 | 527.6 | +120.1 | 1.29x | 30.5 | 71.8 |
| GetValue | 2,000,000 | 11.1 | 38.5 | +27.4 | 3.46x | 3.9 | 4.6 |
| Transaction | 20,000 | 2279.1 | 5087.3 | +2808.3 | 2.23x | 656.8 | 985.5 |
| SyncLocal | 20,000 | 30444.2 | 32519.9 | +2075.7 | 1.07x | 2771.0 | 2647.3 |
| BuildCounter | 100 | 58947.2 | 52052.9 | -6894.3 | 0.88x | 16826.4 | 12154.5 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 829.3 | 3367.8 | +2538.5 | 4.06x | 279.7 | 672.8 |
| Get-64B | 64B | 100,000 | 127.4 | 1791.6 | +1664.2 | 14.06x | 52.4 | 492.5 |
| Transaction-64B | 64B | 400 | 15908.6 | 42726.0 | +26817.4 | 2.69x | 5271.2 | 16867.1 |
| SyncLocal-64B | 64B | 4,000 | 30325.0 | 33881.2 | +3556.2 | 1.12x | 5860.0 | 3262.6 |
| Set-1024B | 1024B | 400 | 2423.4 | 9546.3 | +7122.9 | 3.94x | 1339.4 | 3186.4 |
| Get-1024B | 1024B | 20,000 | 290.8 | 4783.4 | +4492.7 | 16.45x | 183.2 | 891.0 |
| Transaction-1024B | 1024B | 40 | 22121.2 | 123744.2 | +101623.0 | 5.59x | 11470.3 | 36326.6 |
| SyncLocal-1024B | 1024B | 400 | 29733.6 | 38579.6 | +8846.0 | 1.30x | 10113.5 | 11166.5 |
| Set-16384B | 16384B | 40 | 26744.4 | 137519.8 | +110775.3 | 5.14x | 12758.8 | 38561.2 |
| Get-16384B | 16384B | 2,000 | 2793.0 | 53562.1 | +50769.1 | 19.18x | 1815.0 | 11265.3 |
| Transaction-16384B | 16384B | 4 | 298099.8 | 1085887.6 | +787787.9 | 3.64x | 172956.8 | 479800.2 |
| SyncLocal-16384B | 16384B | 40 | 64659.0 | 137326.0 | +72667.0 | 2.12x | 41959.9 | 76238.5 |

