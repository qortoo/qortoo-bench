# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T11:17:38.354807+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 390.1 | 481.6 | +91.5 | 1.23x | 44.3 | 45.6 |
| GetValue | 2,000,000 | 9.6 | 37.9 | +28.3 | 3.96x | 4.3 | 4.0 |
| Transaction | 20,000 | 2158.7 | 4335.1 | +2176.5 | 2.01x | 431.7 | 973.5 |
| SyncLocal | 20,000 | 29533.3 | 31507.4 | +1974.1 | 1.07x | 3967.0 | 5677.2 |
| BuildCounter | 100 | 51734.0 | 46573.6 | -5160.4 | 0.90x | 11021.5 | 25328.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 916.3 | 3132.5 | +2216.2 | 3.42x | 270.3 | 689.3 |
| Get-64B | 64B | 100,000 | 127.6 | 1465.0 | +1337.4 | 11.48x | 21.0 | 235.3 |
| Transaction-64B | 64B | 400 | 9300.5 | 35526.3 | +26225.8 | 3.82x | 4535.3 | 14499.3 |
| SyncLocal-64B | 64B | 4,000 | 30816.0 | 33969.2 | +3153.2 | 1.10x | 6009.3 | 3615.7 |
| Set-1024B | 1024B | 400 | 2399.1 | 8931.1 | +6532.0 | 3.72x | 1648.5 | 3858.1 |
| Get-1024B | 1024B | 20,000 | 295.0 | 4563.9 | +4268.9 | 15.47x | 183.9 | 829.4 |
| Transaction-1024B | 1024B | 40 | 23164.9 | 108167.8 | +85002.9 | 4.67x | 16942.0 | 42933.5 |
| SyncLocal-1024B | 1024B | 400 | 30616.5 | 42704.4 | +12087.9 | 1.39x | 9857.5 | 12110.3 |
| Set-16384B | 16384B | 40 | 26221.5 | 130753.5 | +104531.9 | 4.99x | 9063.1 | 46352.8 |
| Get-16384B | 16384B | 2,000 | 2815.6 | 51473.8 | +48658.2 | 18.28x | 1326.9 | 10394.0 |
| Transaction-16384B | 16384B | 4 | 309454.1 | 1065143.0 | +755688.9 | 3.44x | 178300.0 | 415339.5 |
| SyncLocal-16384B | 16384B | 40 | 81903.0 | 151346.3 | +69443.4 | 1.85x | 21670.9 | 49395.6 |

