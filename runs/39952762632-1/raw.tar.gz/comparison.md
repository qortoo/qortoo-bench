# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T12:25:59.299360+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 436.7 | 551.5 | +114.7 | 1.26x | 40.4 | 61.2 |
| GetValue | 2,000,000 | 10.7 | 37.6 | +27.0 | 3.53x | 3.7 | 4.4 |
| Transaction | 20,000 | 2712.5 | 4670.1 | +1957.7 | 1.72x | 464.5 | 793.9 |
| SyncLocal | 20,000 | 25828.6 | 24843.9 | -984.7 | 0.96x | 2135.7 | 1830.0 |
| BuildCounter | 100 | 49010.0 | 36143.7 | -12866.3 | 0.74x | 18477.9 | 18367.2 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1191.4 | 2967.0 | +1775.6 | 2.49x | 437.9 | 776.2 |
| Get-64B | 64B | 100,000 | 151.8 | 1418.2 | +1266.4 | 9.34x | 67.5 | 281.4 |
| Transaction-64B | 64B | 400 | 10022.1 | 33226.4 | +23204.3 | 3.32x | 4897.2 | 13394.5 |
| SyncLocal-64B | 64B | 4,000 | 20374.9 | 22946.2 | +2571.4 | 1.13x | 3678.0 | 6066.1 |
| Set-1024B | 1024B | 400 | 2241.7 | 8835.0 | +6593.3 | 3.94x | 1411.1 | 5262.5 |
| Get-1024B | 1024B | 20,000 | 365.6 | 4569.9 | +4204.3 | 12.50x | 180.0 | 1378.7 |
| Transaction-1024B | 1024B | 40 | 40651.4 | 168879.6 | +128228.2 | 4.15x | 11217.6 | 60003.6 |
| SyncLocal-1024B | 1024B | 400 | 25685.4 | 36460.3 | +10774.9 | 1.42x | 12541.7 | 15097.7 |
| Set-16384B | 16384B | 40 | 37480.3 | 94967.8 | +57487.5 | 2.53x | 22461.4 | 66647.1 |
| Get-16384B | 16384B | 2,000 | 2816.2 | 50968.1 | +48151.9 | 18.10x | 1605.4 | 20174.6 |
| Transaction-16384B | 16384B | 4 | 256723.2 | 1515458.8 | +1258735.5 | 5.90x | 122060.6 | 337907.5 |
| SyncLocal-16384B | 16384B | 40 | 70843.0 | 138457.6 | +67614.6 | 1.95x | 23908.4 | 35674.6 |

