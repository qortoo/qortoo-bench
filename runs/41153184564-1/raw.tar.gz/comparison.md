# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-31T01:04:18.832746+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 390.9 | 541.2 | +150.3 | 1.38x | 30.4 | 73.3 |
| GetValue | 2,000,000 | 5.6 | 36.4 | +30.8 | 6.45x | 4.1 | 4.8 |
| Transaction | 20,000 | 2260.0 | 4481.9 | +2221.9 | 1.98x | 653.4 | 1149.6 |
| SyncLocal | 20,000 | 26261.7 | 31593.3 | +5331.6 | 1.20x | 3897.1 | 5401.1 |
| BuildCounter | 100 | 70854.6 | 65140.2 | -5714.4 | 0.92x | 13018.9 | 15749.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 904.1 | 3789.6 | +2885.5 | 4.19x | 462.0 | 1270.8 |
| Get-64B | 64B | 100,000 | 134.0 | 1245.1 | +1111.2 | 9.29x | 69.8 | 478.8 |
| Transaction-64B | 64B | 400 | 6884.3 | 33241.8 | +26357.5 | 4.83x | 3472.4 | 8716.4 |
| SyncLocal-64B | 64B | 4,000 | 26947.4 | 34168.9 | +7221.5 | 1.27x | 6427.1 | 5270.9 |
| Set-1024B | 1024B | 400 | 2323.4 | 10790.8 | +8467.4 | 4.64x | 1196.0 | 4731.1 |
| Get-1024B | 1024B | 20,000 | 296.3 | 5615.2 | +5319.0 | 18.95x | 188.0 | 1111.6 |
| Transaction-1024B | 1024B | 40 | 22311.2 | 174275.8 | +151964.6 | 7.81x | 16404.5 | 53575.2 |
| SyncLocal-1024B | 1024B | 400 | 28146.4 | 42257.4 | +14111.1 | 1.50x | 11040.7 | 10723.6 |
| Set-16384B | 16384B | 40 | 27401.2 | 133820.9 | +106419.8 | 4.88x | 19881.2 | 69138.4 |
| Get-16384B | 16384B | 2,000 | 3154.2 | 49973.5 | +46819.3 | 15.84x | 1550.1 | 7764.3 |
| Transaction-16384B | 16384B | 4 | 287274.6 | 1014883.4 | +727608.8 | 3.53x | 113035.8 | 458461.4 |
| SyncLocal-16384B | 16384B | 40 | 53344.8 | 164093.9 | +110749.2 | 3.08x | 15782.3 | 57356.3 |

