# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-24T01:02:41.514838+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `2d208ee95a795c0bd6633751930c6216f5005fd4` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 549.5 | 553.1 | +3.6 | 1.01x | 144.3 | 150.8 |
| GetValue | 2,000,000 | 10.5 | 40.8 | +30.3 | 3.90x | 2.9 | 11.7 |
| Transaction | 20,000 | 3185.3 | 5717.8 | +2532.4 | 1.80x | 825.1 | 1342.4 |
| SyncLocal | 20,000 | 46884.6 | 50099.9 | +3215.3 | 1.07x | 8304.1 | 7826.5 |
| BuildCounter | 100 | 80220.5 | 70485.3 | -9735.2 | 0.88x | 45283.5 | 15318.7 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 871.7 | 4983.9 | +4112.2 | 5.72x | 658.3 | 1538.0 |
| Get-64B | 64B | 100,000 | 250.9 | 1661.2 | +1410.4 | 6.62x | 47.1 | 183.4 |
| Transaction-64B | 64B | 400 | 12405.7 | 47237.6 | +34831.9 | 3.81x | 3516.3 | 15053.1 |
| SyncLocal-64B | 64B | 4,000 | 43563.6 | 50465.6 | +6902.1 | 1.16x | 12628.5 | 14796.5 |
| Set-1024B | 1024B | 400 | 2342.4 | 8610.1 | +6267.6 | 3.68x | 3431.9 | 4688.2 |
| Get-1024B | 1024B | 20,000 | 541.9 | 6027.0 | +5485.0 | 11.12x | 178.0 | 1108.6 |
| Transaction-1024B | 1024B | 40 | 22719.7 | 158208.7 | +135489.1 | 6.96x | 19084.9 | 48634.1 |
| SyncLocal-1024B | 1024B | 400 | 35296.8 | 43398.7 | +8101.8 | 1.23x | 11016.5 | 11785.5 |
| Set-16384B | 16384B | 40 | 44028.9 | 145659.4 | +101630.5 | 3.31x | 20005.4 | 71562.8 |
| Get-16384B | 16384B | 2,000 | 4999.4 | 56658.8 | +51659.4 | 11.33x | 1519.6 | 17060.7 |
| Transaction-16384B | 16384B | 4 | 302003.6 | 1449595.8 | +1147592.1 | 4.80x | 237024.3 | 1371305.2 |
| SyncLocal-16384B | 16384B | 40 | 60637.0 | 169828.8 | +109191.8 | 2.80x | 19455.7 | 150395.1 |

