# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-11T23:00:23.685158+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 388.2 | 589.2 | +201.0 | 1.52x | 44.6 | 66.5 |
| GetValue | 2,000,000 | 5.4 | 39.5 | +34.1 | 7.34x | 2.6 | 6.6 |
| Transaction | 20,000 | 2751.6 | 4293.2 | +1541.6 | 1.56x | 600.9 | 936.4 |
| SyncLocal | 20,000 | 22847.5 | 24964.2 | +2116.7 | 1.09x | 1838.1 | 1313.4 |
| BuildCounter | 100 | 47397.1 | 42958.6 | -4438.5 | 0.91x | 9671.6 | 8713.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 859.3 | 3063.7 | +2204.4 | 3.57x | 38.3 | 645.0 |
| Get-64B | 64B | 100,000 | 127.9 | 1449.8 | +1321.9 | 11.33x | 79.5 | 267.8 |
| Transaction-64B | 64B | 400 | 14889.3 | 66920.2 | +52030.9 | 4.49x | 4642.4 | 17518.7 |
| SyncLocal-64B | 64B | 4,000 | 25022.7 | 27963.9 | +2941.2 | 1.12x | 4622.3 | 6589.7 |
| Set-1024B | 1024B | 400 | 2215.1 | 8735.0 | +6519.9 | 3.94x | 826.0 | 428.5 |
| Get-1024B | 1024B | 20,000 | 285.8 | 3566.8 | +3281.0 | 12.48x | 89.1 | 692.9 |
| Transaction-1024B | 1024B | 40 | 22654.8 | 174334.3 | +151679.5 | 7.70x | 12262.3 | 115329.2 |
| SyncLocal-1024B | 1024B | 400 | 31600.9 | 40289.4 | +8688.5 | 1.27x | 11586.7 | 15639.8 |
| Set-16384B | 16384B | 40 | 48180.7 | 152760.5 | +104579.9 | 3.17x | 12738.4 | 36429.7 |
| Get-16384B | 16384B | 2,000 | 2867.1 | 63842.6 | +60975.4 | 22.27x | 1524.2 | 13108.9 |
| Transaction-16384B | 16384B | 4 | 522063.5 | 1835701.2 | +1313637.8 | 3.52x | 167655.0 | 461457.1 |
| SyncLocal-16384B | 16384B | 40 | 93409.6 | 216849.0 | +123439.4 | 2.32x | 28248.3 | 55523.9 |

