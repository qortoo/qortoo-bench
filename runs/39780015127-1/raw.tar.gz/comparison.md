# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T12:42:04.789532+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `47ba481c27c4f09022ca3a07b6794ddafeef0fca` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 368.4 | 475.4 | +106.9 | 1.29x | 3.3 | 47.9 |
| GetValue | 2,000,000 | 5.4 | 36.7 | +31.3 | 6.74x | 0.0 | 0.7 |
| Transaction | 20,000 | 2047.9 | 3592.9 | +1545.0 | 1.75x | 36.0 | 58.8 |
| SyncLocal | 20,000 | 22583.6 | 23984.5 | +1401.0 | 1.06x | 607.3 | 333.5 |
| BuildCounter | 100 | 40481.3 | 38070.6 | -2410.7 | 0.94x | 1080.1 | 1200.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 805.4 | 2901.2 | +2095.8 | 3.60x | 18.9 | 44.0 |
| Get-64B | 64B | 100,000 | 130.0 | 989.1 | +859.1 | 7.61x | 3.2 | 9.1 |
| Transaction-64B | 64B | 400 | 6443.8 | 28820.7 | +22376.9 | 4.47x | 285.6 | 787.4 |
| SyncLocal-64B | 64B | 4,000 | 19325.7 | 23357.5 | +4031.8 | 1.21x | 935.9 | 567.0 |
| Set-1024B | 1024B | 400 | 2085.2 | 8274.3 | +6189.1 | 3.97x | 60.8 | 313.4 |
| Get-1024B | 1024B | 20,000 | 284.6 | 3122.0 | +2837.4 | 10.97x | 3.5 | 52.8 |
| Transaction-1024B | 1024B | 40 | 20234.3 | 87941.6 | +67707.3 | 4.35x | 663.2 | 2472.5 |
| SyncLocal-1024B | 1024B | 400 | 19391.9 | 26351.9 | +6960.0 | 1.36x | 462.4 | 348.2 |
| Set-16384B | 16384B | 40 | 23394.2 | 77520.0 | +54125.9 | 3.31x | 804.6 | 4731.4 |
| Get-16384B | 16384B | 2,000 | 2773.8 | 32670.8 | +29896.9 | 11.78x | 42.6 | 464.4 |
| Transaction-16384B | 16384B | 4 | 245846.6 | 827506.9 | +581660.2 | 3.37x | 11595.3 | 23705.3 |
| SyncLocal-16384B | 16384B | 40 | 44169.7 | 98408.2 | +54238.5 | 2.23x | 769.7 | 3663.1 |

