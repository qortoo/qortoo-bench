# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T00:09:40.780905+00:00
- **Platform**: `Linux-7.0.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `dda1d35d8b12e8d3d6310079c3bbf8dfa4e1a7b5` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 426.1 | 628.1 | +202.0 | 1.47x | 3.6 | 24.8 |
| GetValue | 2,000,000 | 6.6 | 41.9 | +35.3 | 6.31x | 0.0 | 1.1 |
| Transaction | 20,000 | 2437.8 | 4787.9 | +2350.2 | 1.96x | 44.4 | 244.6 |
| SyncLocal | 20,000 | 28643.1 | 30736.1 | +2093.0 | 1.07x | 1337.7 | 1389.3 |
| BuildCounter | 100 | 63050.0 | 60587.7 | -2462.3 | 0.96x | 1489.0 | 2035.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1007.8 | 4474.4 | +3466.6 | 4.44x | 19.3 | 170.2 |
| Get-64B | 64B | 100,000 | 148.5 | 1360.9 | +1212.3 | 9.16x | 1.2 | 13.8 |
| Transaction-64B | 64B | 400 | 8242.7 | 45243.6 | +37000.9 | 5.49x | 109.4 | 1867.3 |
| SyncLocal-64B | 64B | 4,000 | 25411.7 | 34295.8 | +8884.2 | 1.35x | 1195.6 | 2017.4 |
| Set-1024B | 1024B | 400 | 2541.6 | 15946.4 | +13404.8 | 6.27x | 201.8 | 928.5 |
| Get-1024B | 1024B | 20,000 | 341.1 | 4135.4 | +3794.3 | 12.12x | 24.4 | 55.3 |
| Transaction-1024B | 1024B | 40 | 23989.2 | 165467.0 | +141477.8 | 6.90x | 877.9 | 9865.1 |
| SyncLocal-1024B | 1024B | 400 | 26475.6 | 47420.4 | +20944.8 | 1.79x | 644.1 | 987.4 |
| Set-16384B | 16384B | 40 | 28143.7 | 141717.0 | +113573.3 | 5.04x | 1376.8 | 5439.5 |
| Get-16384B | 16384B | 2,000 | 3294.9 | 42158.4 | +38863.5 | 12.80x | 845.6 | 1399.2 |
| Transaction-16384B | 16384B | 4 | 313681.6 | 1514901.5 | +1201219.9 | 4.83x | 13867.7 | 42413.3 |
| SyncLocal-16384B | 16384B | 40 | 58460.3 | 184401.3 | +125941.0 | 3.15x | 1228.4 | 4698.7 |

