# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-25T05:39:53.272358+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 390.6 | 515.4 | +124.8 | 1.32x | 55.9 | 78.0 |
| GetValue | 2,000,000 | 5.5 | 38.1 | +32.7 | 6.97x | 3.2 | 3.5 |
| Transaction | 20,000 | 2327.8 | 4462.1 | +2134.3 | 1.92x | 525.4 | 850.2 |
| SyncLocal | 20,000 | 30392.5 | 35333.6 | +4941.1 | 1.16x | 2356.8 | 3851.1 |
| BuildCounter | 100 | 71240.3 | 51960.0 | -19280.3 | 0.73x | 16575.3 | 22352.3 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1043.8 | 3291.8 | +2248.1 | 3.15x | 436.8 | 1249.1 |
| Get-64B | 64B | 100,000 | 128.9 | 1510.5 | +1381.6 | 11.72x | 88.9 | 329.8 |
| Transaction-64B | 64B | 400 | 7255.5 | 43118.6 | +35863.1 | 5.94x | 3885.5 | 14153.9 |
| SyncLocal-64B | 64B | 4,000 | 31212.9 | 39074.7 | +7861.8 | 1.25x | 8650.6 | 8103.1 |
| Set-1024B | 1024B | 400 | 2230.3 | 8948.3 | +6718.0 | 4.01x | 2207.4 | 3514.0 |
| Get-1024B | 1024B | 20,000 | 281.6 | 5022.4 | +4740.8 | 17.83x | 156.6 | 962.8 |
| Transaction-1024B | 1024B | 40 | 23299.6 | 115272.5 | +91972.9 | 4.95x | 37908.2 | 35053.6 |
| SyncLocal-1024B | 1024B | 400 | 39174.8 | 54669.1 | +15494.4 | 1.40x | 11352.0 | 12573.0 |
| Set-16384B | 16384B | 40 | 27918.5 | 126094.6 | +98176.1 | 4.52x | 34300.6 | 67128.4 |
| Get-16384B | 16384B | 2,000 | 2763.7 | 51723.5 | +48959.9 | 18.72x | 629.8 | 9367.2 |
| Transaction-16384B | 16384B | 4 | 284487.2 | 1067489.5 | +783002.2 | 3.75x | 11626.0 | 280510.4 |
| SyncLocal-16384B | 16384B | 40 | 57383.5 | 161818.2 | +104434.8 | 2.82x | 32870.8 | 91334.4 |

