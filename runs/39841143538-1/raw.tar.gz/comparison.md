# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T19:37:58.363587+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `47ba481c27c4f09022ca3a07b6794ddafeef0fca` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 418.4 | 601.3 | +182.9 | 1.44x | 5.7 | 34.5 |
| GetValue | 2,000,000 | 6.7 | 41.6 | +34.8 | 6.16x | 0.1 | 0.8 |
| Transaction | 20,000 | 2381.5 | 4751.4 | +2370.0 | 2.00x | 32.2 | 236.7 |
| SyncLocal | 20,000 | 37974.2 | 39963.6 | +1989.4 | 1.05x | 1180.0 | 771.5 |
| BuildCounter | 100 | 59433.7 | 56800.5 | -2633.2 | 0.96x | 1154.3 | 888.7 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 979.5 | 3987.2 | +3007.7 | 4.07x | 12.0 | 96.6 |
| Get-64B | 64B | 100,000 | 147.7 | 1339.1 | +1191.4 | 9.07x | 1.8 | 8.6 |
| Transaction-64B | 64B | 400 | 8136.2 | 40450.9 | +32314.8 | 4.97x | 90.1 | 960.4 |
| SyncLocal-64B | 64B | 4,000 | 29842.3 | 40703.3 | +10861.1 | 1.36x | 2085.6 | 3097.9 |
| Set-1024B | 1024B | 400 | 2430.0 | 11604.4 | +9174.4 | 4.78x | 43.6 | 549.0 |
| Get-1024B | 1024B | 20,000 | 342.5 | 3968.0 | +3625.5 | 11.58x | 4.1 | 106.6 |
| Transaction-1024B | 1024B | 40 | 23155.4 | 133651.8 | +110496.4 | 5.77x | 1358.0 | 11175.1 |
| SyncLocal-1024B | 1024B | 400 | 25039.8 | 40119.1 | +15079.3 | 1.60x | 618.2 | 1538.1 |
| Set-16384B | 16384B | 40 | 25902.1 | 112056.1 | +86154.0 | 4.33x | 1366.9 | 6605.7 |
| Get-16384B | 16384B | 2,000 | 5900.9 | 39629.2 | +33728.3 | 6.72x | 1783.0 | 1694.3 |
| Transaction-16384B | 16384B | 4 | 287948.1 | 1215520.5 | +927572.4 | 4.22x | 9950.2 | 55411.3 |
| SyncLocal-16384B | 16384B | 40 | 55005.6 | 150609.5 | +95603.8 | 2.74x | 911.7 | 2664.3 |

