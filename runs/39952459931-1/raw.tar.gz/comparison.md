# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T12:24:32.002150+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 423.8 | 552.4 | +128.7 | 1.30x | 75.6 | 84.9 |
| GetValue | 2,000,000 | 7.0 | 46.1 | +39.0 | 6.56x | 2.8 | 5.0 |
| Transaction | 20,000 | 2411.2 | 4674.7 | +2263.6 | 1.94x | 380.4 | 510.4 |
| SyncLocal | 20,000 | 35589.9 | 43560.3 | +7970.4 | 1.22x | 7131.0 | 14804.4 |
| BuildCounter | 100 | 69276.4 | 61528.6 | -7747.8 | 0.89x | 19488.6 | 19422.4 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 883.2 | 3568.3 | +2685.1 | 4.04x | 233.8 | 1412.1 |
| Get-64B | 64B | 100,000 | 132.4 | 1481.5 | +1349.1 | 11.19x | 55.2 | 230.2 |
| Transaction-64B | 64B | 400 | 10439.8 | 42281.3 | +31841.5 | 4.05x | 3127.3 | 12264.2 |
| SyncLocal-64B | 64B | 4,000 | 31818.0 | 36987.9 | +5169.9 | 1.16x | 11528.7 | 21144.3 |
| Set-1024B | 1024B | 400 | 2275.9 | 13154.8 | +10878.9 | 5.78x | 1011.0 | 4076.6 |
| Get-1024B | 1024B | 20,000 | 409.7 | 4918.0 | +4508.3 | 12.01x | 127.1 | 904.4 |
| Transaction-1024B | 1024B | 40 | 22435.3 | 156574.8 | +134139.5 | 6.98x | 11501.7 | 34216.0 |
| SyncLocal-1024B | 1024B | 400 | 29732.0 | 44027.3 | +14295.3 | 1.48x | 9135.3 | 11640.3 |
| Set-16384B | 16384B | 40 | 27346.4 | 108205.1 | +80858.8 | 3.96x | 7868.6 | 34727.9 |
| Get-16384B | 16384B | 2,000 | 2868.0 | 57933.7 | +55065.7 | 20.20x | 1382.6 | 9612.1 |
| Transaction-16384B | 16384B | 4 | 319820.9 | 1293536.8 | +973715.9 | 4.04x | 227336.4 | 676312.2 |
| SyncLocal-16384B | 16384B | 40 | 72501.1 | 178319.9 | +105818.7 | 2.46x | 33440.7 | 55548.5 |

