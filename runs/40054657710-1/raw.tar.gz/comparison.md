# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-24T02:38:10.373988+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `2f2b869579787e2bb736fa9e324d773f3f2db89a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 403.1 | 534.9 | +131.8 | 1.33x | 49.3 | 76.0 |
| GetValue | 2,000,000 | 5.7 | 44.3 | +38.6 | 7.74x | 3.2 | 9.2 |
| Transaction | 20,000 | 2257.4 | 4669.8 | +2412.4 | 2.07x | 487.7 | 871.2 |
| SyncLocal | 20,000 | 29212.3 | 35765.9 | +6553.6 | 1.22x | 5009.1 | 5165.6 |
| BuildCounter | 100 | 65192.2 | 48007.9 | -17184.2 | 0.74x | 23892.8 | 9715.3 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 904.8 | 3281.8 | +2376.9 | 3.63x | 396.7 | 556.9 |
| Get-64B | 64B | 100,000 | 133.5 | 1488.8 | +1355.3 | 11.15x | 24.3 | 233.0 |
| Transaction-64B | 64B | 400 | 6924.0 | 42828.6 | +35904.6 | 6.19x | 3881.1 | 15056.2 |
| SyncLocal-64B | 64B | 4,000 | 33803.8 | 34641.7 | +837.9 | 1.02x | 13502.7 | 8687.4 |
| Set-1024B | 1024B | 400 | 2240.8 | 8579.2 | +6338.4 | 3.83x | 212.7 | 5126.1 |
| Get-1024B | 1024B | 20,000 | 285.9 | 5296.9 | +5011.1 | 18.53x | 138.3 | 566.7 |
| Transaction-1024B | 1024B | 40 | 21292.8 | 125087.8 | +103795.0 | 5.87x | 14354.3 | 53706.3 |
| SyncLocal-1024B | 1024B | 400 | 22731.9 | 55590.8 | +32858.9 | 2.45x | 9859.2 | 21039.0 |
| Set-16384B | 16384B | 40 | 26621.3 | 118153.7 | +91532.4 | 4.44x | 13922.5 | 61692.9 |
| Get-16384B | 16384B | 2,000 | 2851.2 | 56018.6 | +53167.4 | 19.65x | 2142.1 | 8846.1 |
| Transaction-16384B | 16384B | 4 | 295769.6 | 1123637.4 | +827867.8 | 3.80x | 227732.3 | 709586.0 |
| SyncLocal-16384B | 16384B | 40 | 69617.9 | 140859.4 | +71241.6 | 2.02x | 26294.4 | 52026.5 |

