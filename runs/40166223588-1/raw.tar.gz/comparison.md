# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-25T05:42:25.548536+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 457.8 | 646.9 | +189.0 | 1.41x | 44.0 | 123.4 |
| GetValue | 2,000,000 | 7.5 | 42.0 | +34.5 | 5.63x | 2.3 | 12.2 |
| Transaction | 20,000 | 2515.5 | 4269.9 | +1754.4 | 1.70x | 586.5 | 710.1 |
| SyncLocal | 20,000 | 39086.2 | 49625.6 | +10539.4 | 1.27x | 8555.4 | 8969.2 |
| BuildCounter | 100 | 73388.8 | 65642.0 | -7746.8 | 0.89x | 37454.0 | 42619.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 891.8 | 3800.1 | +2908.3 | 4.26x | 307.8 | 1438.1 |
| Get-64B | 64B | 100,000 | 142.0 | 1472.1 | +1330.1 | 10.37x | 13.5 | 233.8 |
| Transaction-64B | 64B | 400 | 7090.4 | 36795.7 | +29705.3 | 5.19x | 3339.7 | 6911.0 |
| SyncLocal-64B | 64B | 4,000 | 38481.3 | 44956.0 | +6474.7 | 1.17x | 9273.7 | 14053.2 |
| Set-1024B | 1024B | 400 | 2346.4 | 10312.6 | +7966.2 | 4.40x | 3205.4 | 4500.4 |
| Get-1024B | 1024B | 20,000 | 328.5 | 5225.5 | +4897.0 | 15.91x | 99.2 | 779.7 |
| Transaction-1024B | 1024B | 40 | 23555.1 | 181409.8 | +157854.7 | 7.70x | 13465.2 | 81521.8 |
| SyncLocal-1024B | 1024B | 400 | 35517.2 | 56799.9 | +21282.8 | 1.60x | 7795.3 | 14658.3 |
| Set-16384B | 16384B | 40 | 26861.6 | 131111.8 | +104250.2 | 4.88x | 18925.2 | 45218.1 |
| Get-16384B | 16384B | 2,000 | 2959.9 | 58801.9 | +55842.1 | 19.87x | 1488.6 | 18094.2 |
| Transaction-16384B | 16384B | 4 | 286392.1 | 1424864.2 | +1138472.1 | 4.98x | 194421.2 | 827655.7 |
| SyncLocal-16384B | 16384B | 40 | 88901.1 | 192629.2 | +103728.1 | 2.17x | 84464.8 | 58653.9 |

