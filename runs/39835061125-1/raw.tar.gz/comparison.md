# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T18:56:04.787119+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `47ba481c27c4f09022ca3a07b6794ddafeef0fca` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 498.2 | 619.5 | +121.3 | 1.24x | 8.6 | 21.4 |
| GetValue | 2,000,000 | 17.9 | 53.2 | +35.2 | 2.97x | 0.5 | 2.0 |
| Transaction | 20,000 | 2502.9 | 4667.3 | +2164.4 | 1.86x | 20.6 | 81.9 |
| SyncLocal | 20,000 | 29772.1 | 31365.3 | +1593.3 | 1.05x | 1435.5 | 963.3 |
| BuildCounter | 100 | 44178.3 | 41581.5 | -2596.8 | 0.94x | 2158.6 | 1614.1 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1012.0 | 3892.7 | +2880.7 | 3.85x | 55.6 | 166.7 |
| Get-64B | 64B | 100,000 | 155.7 | 1317.5 | +1161.8 | 8.46x | 3.1 | 27.7 |
| Transaction-64B | 64B | 400 | 7900.2 | 38258.5 | +30358.3 | 4.84x | 100.9 | 918.7 |
| SyncLocal-64B | 64B | 4,000 | 27671.7 | 33306.1 | +5634.4 | 1.20x | 985.9 | 1623.9 |
| Set-1024B | 1024B | 400 | 2331.8 | 10244.5 | +7912.7 | 4.39x | 48.9 | 841.6 |
| Get-1024B | 1024B | 20,000 | 343.7 | 3839.7 | +3496.0 | 11.17x | 26.5 | 51.7 |
| Transaction-1024B | 1024B | 40 | 21727.3 | 111024.2 | +89296.9 | 5.11x | 1354.7 | 6687.7 |
| SyncLocal-1024B | 1024B | 400 | 26969.9 | 37627.6 | +10657.7 | 1.40x | 1657.8 | 6610.2 |
| Set-16384B | 16384B | 40 | 22885.8 | 91228.5 | +68342.7 | 3.99x | 369.8 | 5632.8 |
| Get-16384B | 16384B | 2,000 | 3386.5 | 38537.9 | +35151.4 | 11.38x | 20.7 | 823.6 |
| Transaction-16384B | 16384B | 4 | 244173.9 | 977920.1 | +733746.2 | 4.01x | 2117.3 | 72764.6 |
| SyncLocal-16384B | 16384B | 40 | 49815.1 | 128028.7 | +78213.6 | 2.57x | 1484.8 | 5384.9 |

