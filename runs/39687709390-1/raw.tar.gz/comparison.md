# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-21T22:41:08.776965+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `e849a4eff55bc1cb03b28b5a5078f4ae73d85015` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 415.7 | 566.5 | +150.8 | 1.36x | 9.8 | 48.4 |
| GetValue | 2,000,000 | 6.7 | 41.7 | +35.0 | 6.21x | 0.1 | 0.9 |
| Transaction | 20,000 | 2407.9 | 4681.0 | +2273.1 | 1.94x | 26.1 | 135.2 |
| SyncLocal | 20,000 | 38359.5 | 41209.3 | +2849.8 | 1.07x | 915.5 | 1005.3 |
| BuildCounter | 100 | 61907.3 | 57849.2 | -4058.1 | 0.93x | 2568.1 | 2535.5 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 989.2 | 4089.3 | +3100.1 | 4.13x | 25.7 | 187.2 |
| Get-64B | 64B | 100,000 | 145.7 | 1366.9 | +1221.2 | 9.38x | 2.8 | 47.5 |
| Transaction-64B | 64B | 400 | 8175.0 | 42578.1 | +34403.1 | 5.21x | 196.1 | 1828.0 |
| SyncLocal-64B | 64B | 4,000 | 29876.4 | 40948.4 | +11072.0 | 1.37x | 930.1 | 2321.7 |
| Set-1024B | 1024B | 400 | 2505.2 | 12286.4 | +9781.2 | 4.90x | 60.2 | 641.6 |
| Get-1024B | 1024B | 20,000 | 337.4 | 4029.1 | +3691.7 | 11.94x | 2.5 | 72.4 |
| Transaction-1024B | 1024B | 40 | 23334.0 | 134606.0 | +111272.0 | 5.77x | 776.5 | 5875.2 |
| SyncLocal-1024B | 1024B | 400 | 25704.2 | 41185.1 | +15480.9 | 1.60x | 721.4 | 1896.0 |
| Set-16384B | 16384B | 40 | 27537.8 | 121968.2 | +94430.4 | 4.43x | 800.8 | 3370.3 |
| Get-16384B | 16384B | 2,000 | 3260.3 | 41119.3 | +37859.0 | 12.61x | 1349.7 | 838.9 |
| Transaction-16384B | 16384B | 4 | 287405.1 | 1253455.8 | +966050.6 | 4.36x | 9557.9 | 65534.6 |
| SyncLocal-16384B | 16384B | 40 | 55885.0 | 155358.6 | +99473.6 | 2.78x | 1069.5 | 4477.2 |

