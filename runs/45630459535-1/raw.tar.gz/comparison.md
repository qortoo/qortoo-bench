# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-25T14:10:31.010891+00:00
- **Platform**: `Linux-6.14.0-1018-aws-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `90c62f83eb2be87165f486cbe03137b43d8ee4d5` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 328.2 | 388.0 | +59.8 | 1.18x | 4.4 | 12.0 |
| GetValue | 2,000,000 | 9.8 | 34.2 | +24.4 | 3.50x | 0.0 | 0.2 |
| Transaction | 20,000 | 2112.4 | 3168.3 | +1055.9 | 1.50x | 33.3 | 37.5 |
| SyncLocal | 20,000 | 5843.7 | 5838.9 | -4.9 | 1.00x | 35.8 | 49.1 |
| BuildCounter | 100 | 15446.6 | 12524.5 | -2922.2 | 0.81x | 762.1 | 645.7 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 618.8 | 2145.2 | +1526.4 | 3.47x | 166.2 | 79.7 |
| Get-64B | 64B | 100,000 | 91.1 | 707.8 | +616.7 | 7.77x | 0.9 | 3.3 |
| Transaction-64B | 64B | 400 | 5169.8 | 21143.5 | +15973.7 | 4.09x | 80.1 | 650.4 |
| SyncLocal-64B | 64B | 4,000 | 5424.7 | 7618.6 | +2193.8 | 1.40x | 45.7 | 81.7 |
| Set-1024B | 1024B | 400 | 1281.7 | 5963.3 | +4681.7 | 4.65x | 32.3 | 272.9 |
| Get-1024B | 1024B | 20,000 | 197.1 | 2174.3 | +1977.2 | 11.03x | 2.2 | 15.8 |
| Transaction-1024B | 1024B | 40 | 12221.9 | 59692.2 | +47470.3 | 4.88x | 405.7 | 2098.3 |
| SyncLocal-1024B | 1024B | 400 | 6912.1 | 11549.6 | +4637.4 | 1.67x | 85.5 | 245.0 |
| Set-16384B | 16384B | 40 | 11450.6 | 50641.4 | +39190.8 | 4.42x | 486.7 | 2128.4 |
| Get-16384B | 16384B | 2,000 | 1950.1 | 20545.4 | +18595.3 | 10.54x | 9.4 | 152.1 |
| Transaction-16384B | 16384B | 4 | 128710.9 | 519064.2 | +390353.4 | 4.03x | 14102.5 | 31778.0 |
| SyncLocal-16384B | 16384B | 40 | 22212.4 | 60335.2 | +38122.8 | 2.72x | 646.6 | 1721.4 |

