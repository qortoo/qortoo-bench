# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-14T01:11:00.182628+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 280.5 | 356.3 | +75.8 | 1.27x | 7.8 | 16.7 |
| GetValue | 2,000,000 | 4.2 | 28.8 | +24.6 | 6.83x | 0.0 | 0.7 |
| Transaction | 20,000 | 1555.5 | 2809.5 | +1253.9 | 1.81x | 93.7 | 236.9 |
| SyncLocal | 20,000 | 18354.7 | 18405.7 | +51.0 | 1.00x | 1555.1 | 2154.0 |
| BuildCounter | 100 | 36874.8 | 33388.7 | -3486.1 | 0.91x | 1893.1 | 1929.2 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 635.9 | 2349.1 | +1713.1 | 3.69x | 35.6 | 110.6 |
| Get-64B | 64B | 100,000 | 97.5 | 803.1 | +705.6 | 8.24x | 1.3 | 15.1 |
| Transaction-64B | 64B | 400 | 5170.6 | 22955.8 | +17785.2 | 4.44x | 95.7 | 1057.8 |
| SyncLocal-64B | 64B | 4,000 | 13296.9 | 18708.7 | +5411.8 | 1.41x | 1534.4 | 2374.5 |
| Set-1024B | 1024B | 400 | 1797.6 | 7040.6 | +5243.0 | 3.92x | 189.5 | 1139.8 |
| Get-1024B | 1024B | 20,000 | 217.1 | 2573.3 | +2356.2 | 11.85x | 2.4 | 130.8 |
| Transaction-1024B | 1024B | 40 | 16767.6 | 73694.4 | +56926.8 | 4.40x | 1075.5 | 8826.1 |
| SyncLocal-1024B | 1024B | 400 | 14496.1 | 20818.3 | +6322.2 | 1.44x | 1292.1 | 1454.3 |
| Set-16384B | 16384B | 40 | 19763.8 | 66701.2 | +46937.3 | 3.37x | 759.8 | 14265.4 |
| Get-16384B | 16384B | 2,000 | 2244.8 | 27124.9 | +24880.1 | 12.08x | 23.8 | 673.0 |
| Transaction-16384B | 16384B | 4 | 209531.0 | 737870.4 | +528339.4 | 3.52x | 10196.3 | 74431.8 |
| SyncLocal-16384B | 16384B | 40 | 40496.8 | 91476.2 | +50979.4 | 2.26x | 6247.8 | 9822.4 |

