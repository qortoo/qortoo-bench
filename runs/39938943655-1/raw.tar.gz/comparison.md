# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T10:29:05.976907+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 394.4 | 484.2 | +89.8 | 1.23x | 52.7 | 65.7 |
| GetValue | 2,000,000 | 5.4 | 36.9 | +31.5 | 6.82x | 2.6 | 2.0 |
| Transaction | 20,000 | 2172.0 | 3872.4 | +1700.4 | 1.78x | 600.6 | 1022.3 |
| SyncLocal | 20,000 | 24739.1 | 40655.5 | +15916.4 | 1.64x | 2578.3 | 5233.0 |
| BuildCounter | 100 | 63367.3 | 61921.9 | -1445.4 | 0.98x | 14844.9 | 14692.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 833.0 | 3073.6 | +2240.7 | 3.69x | 88.4 | 729.4 |
| Get-64B | 64B | 100,000 | 127.6 | 1312.6 | +1185.0 | 10.28x | 51.7 | 328.1 |
| Transaction-64B | 64B | 400 | 6711.3 | 31589.1 | +24877.7 | 4.71x | 4201.0 | 13132.9 |
| SyncLocal-64B | 64B | 4,000 | 22206.0 | 31399.8 | +9193.8 | 1.41x | 6465.8 | 3777.4 |
| Set-1024B | 1024B | 400 | 2265.2 | 12009.3 | +9744.1 | 5.30x | 1115.1 | 4631.1 |
| Get-1024B | 1024B | 20,000 | 285.8 | 5028.1 | +4742.3 | 17.59x | 158.8 | 913.7 |
| Transaction-1024B | 1024B | 40 | 21375.4 | 150598.5 | +129223.0 | 7.05x | 14394.0 | 40912.3 |
| SyncLocal-1024B | 1024B | 400 | 21988.3 | 40630.2 | +18641.9 | 1.85x | 11233.8 | 8187.6 |
| Set-16384B | 16384B | 40 | 25596.3 | 108535.0 | +82938.6 | 4.24x | 18961.6 | 45354.7 |
| Get-16384B | 16384B | 2,000 | 2768.8 | 59229.5 | +56460.6 | 21.39x | 1202.9 | 15404.3 |
| Transaction-16384B | 16384B | 4 | 273096.9 | 1573499.4 | +1300402.5 | 5.76x | 159615.1 | 501834.6 |
| SyncLocal-16384B | 16384B | 40 | 52534.6 | 197880.5 | +145345.9 | 3.77x | 36533.3 | 65459.8 |

