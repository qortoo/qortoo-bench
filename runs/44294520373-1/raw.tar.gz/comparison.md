# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-18T11:30:45.315344+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 481.5 | 630.5 | +149.0 | 1.31x | 50.2 | 112.9 |
| GetValue | 2,000,000 | 5.6 | 40.9 | +35.4 | 7.37x | 4.1 | 4.7 |
| Transaction | 20,000 | 3275.5 | 5254.5 | +1979.0 | 1.60x | 646.4 | 716.1 |
| SyncLocal | 20,000 | 30818.4 | 33024.7 | +2206.3 | 1.07x | 986.5 | 2191.4 |
| BuildCounter | 100 | 61443.2 | 54250.1 | -7193.1 | 0.88x | 2326.7 | 2034.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 952.5 | 3467.8 | +2515.3 | 3.64x | 51.7 | 144.9 |
| Get-64B | 64B | 100,000 | 179.8 | 1546.5 | +1366.7 | 8.60x | 76.0 | 238.5 |
| Transaction-64B | 64B | 400 | 17285.3 | 76384.9 | +59099.6 | 4.42x | 4291.3 | 20126.9 |
| SyncLocal-64B | 64B | 4,000 | 31577.7 | 39381.2 | +7803.5 | 1.25x | 3654.0 | 4560.6 |
| Set-1024B | 1024B | 400 | 2592.9 | 9826.4 | +7233.5 | 3.79x | 879.1 | 1485.4 |
| Get-1024B | 1024B | 20,000 | 300.3 | 3961.3 | +3661.0 | 13.19x | 158.5 | 515.0 |
| Transaction-1024B | 1024B | 40 | 26213.1 | 158556.1 | +132343.0 | 6.05x | 12084.0 | 43356.7 |
| SyncLocal-1024B | 1024B | 400 | 37116.7 | 50410.4 | +13293.7 | 1.36x | 8386.8 | 9980.5 |
| Set-16384B | 16384B | 40 | 28957.2 | 107526.4 | +78569.2 | 3.71x | 13545.6 | 29286.0 |
| Get-16384B | 16384B | 2,000 | 3186.7 | 58461.6 | +55275.0 | 18.35x | 2024.6 | 15744.4 |
| Transaction-16384B | 16384B | 4 | 739921.2 | 2081114.6 | +1341193.4 | 2.81x | 213302.8 | 595058.1 |
| SyncLocal-16384B | 16384B | 40 | 117628.1 | 240731.8 | +123103.6 | 2.05x | 33878.9 | 58721.0 |

