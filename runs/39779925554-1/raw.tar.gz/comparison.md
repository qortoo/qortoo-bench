# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-22T12:41:27.551658+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `47ba481c27c4f09022ca3a07b6794ddafeef0fca` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 371.3 | 459.3 | +88.0 | 1.24x | 2.4 | 20.9 |
| GetValue | 2,000,000 | 5.5 | 36.6 | +31.2 | 6.71x | 0.0 | 0.1 |
| Transaction | 20,000 | 2043.0 | 3607.5 | +1564.5 | 1.77x | 49.1 | 124.0 |
| SyncLocal | 20,000 | 23029.7 | 24671.4 | +1641.7 | 1.07x | 617.0 | 521.0 |
| BuildCounter | 100 | 41330.8 | 38748.9 | -2581.9 | 0.94x | 1210.5 | 826.5 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 808.3 | 2988.5 | +2180.1 | 3.70x | 22.9 | 50.4 |
| Get-64B | 64B | 100,000 | 130.7 | 997.7 | +867.0 | 7.63x | 8.8 | 11.1 |
| Transaction-64B | 64B | 400 | 6606.8 | 29406.4 | +22799.6 | 4.45x | 173.7 | 664.1 |
| SyncLocal-64B | 64B | 4,000 | 19941.4 | 23967.8 | +4026.4 | 1.20x | 752.4 | 1221.1 |
| Set-1024B | 1024B | 400 | 2184.8 | 8522.3 | +6337.5 | 3.90x | 62.4 | 278.0 |
| Get-1024B | 1024B | 20,000 | 283.5 | 3143.7 | +2860.2 | 11.09x | 3.4 | 37.4 |
| Transaction-1024B | 1024B | 40 | 20179.6 | 90600.4 | +70420.8 | 4.49x | 465.9 | 2027.7 |
| SyncLocal-1024B | 1024B | 400 | 19987.5 | 27157.0 | +7169.5 | 1.36x | 422.2 | 522.2 |
| Set-16384B | 16384B | 40 | 24626.6 | 80417.6 | +55791.0 | 3.27x | 735.6 | 2438.6 |
| Get-16384B | 16384B | 2,000 | 2778.4 | 33019.5 | +30241.1 | 11.88x | 25.9 | 547.4 |
| Transaction-16384B | 16384B | 4 | 252048.2 | 851968.2 | +599920.0 | 3.38x | 7476.3 | 31461.0 |
| SyncLocal-16384B | 16384B | 40 | 44586.2 | 102135.1 | +57548.9 | 2.29x | 605.7 | 2791.3 |

