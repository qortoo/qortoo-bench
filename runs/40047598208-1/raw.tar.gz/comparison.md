# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-24T01:02:23.879166+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `2d208ee95a795c0bd6633751930c6216f5005fd4` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 418.7 | 532.7 | +114.0 | 1.27x | 31.6 | 87.7 |
| GetValue | 2,000,000 | 5.4 | 39.3 | +33.9 | 7.25x | 2.6 | 3.9 |
| Transaction | 20,000 | 2715.2 | 5114.5 | +2399.3 | 1.88x | 647.4 | 1009.0 |
| SyncLocal | 20,000 | 32075.1 | 33509.7 | +1434.6 | 1.04x | 3653.2 | 6497.3 |
| BuildCounter | 100 | 64497.3 | 59852.2 | -4645.1 | 0.93x | 24003.1 | 15659.6 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 864.0 | 3662.9 | +2798.9 | 4.24x | 395.9 | 858.1 |
| Get-64B | 64B | 100,000 | 139.3 | 1511.9 | +1372.6 | 10.85x | 32.1 | 264.0 |
| Transaction-64B | 64B | 400 | 12456.4 | 49330.6 | +36874.2 | 3.96x | 3912.9 | 11887.2 |
| SyncLocal-64B | 64B | 4,000 | 31722.8 | 34299.8 | +2577.0 | 1.08x | 7551.6 | 5775.0 |
| Set-1024B | 1024B | 400 | 2342.0 | 12726.4 | +10384.4 | 5.43x | 664.3 | 4959.2 |
| Get-1024B | 1024B | 20,000 | 301.3 | 5003.4 | +4702.1 | 16.61x | 52.2 | 699.5 |
| Transaction-1024B | 1024B | 40 | 22507.9 | 140682.2 | +118174.3 | 6.25x | 11810.2 | 76511.0 |
| SyncLocal-1024B | 1024B | 400 | 32930.0 | 37837.8 | +4907.8 | 1.15x | 10407.8 | 14008.0 |
| Set-16384B | 16384B | 40 | 26683.0 | 90264.9 | +63581.9 | 3.38x | 14238.0 | 35293.5 |
| Get-16384B | 16384B | 2,000 | 2809.0 | 48910.4 | +46101.4 | 17.41x | 1032.2 | 8273.3 |
| Transaction-16384B | 16384B | 4 | 294454.0 | 1287797.6 | +993343.6 | 4.37x | 82962.1 | 466058.8 |
| SyncLocal-16384B | 16384B | 40 | 70587.8 | 147838.9 | +77251.2 | 2.09x | 28811.8 | 50874.1 |

