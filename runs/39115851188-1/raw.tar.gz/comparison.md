# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-18T09:36:48.420772+00:00
- **Platform**: `Linux-6.17.0-1022-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `83062e961c74299a60061b2b1f6b98ad492c9d4b` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 410.4 | 475.8 | +65.4 | 1.16x | 24.4 | 26.2 |
| GetValue | 2,000,000 | 10.9 | 37.5 | +26.6 | 3.43x | 0.2 | 1.1 |
| Transaction | 20,000 | 2490.9 | 3714.9 | +1223.9 | 1.49x | 46.5 | 375.6 |
| SyncLocal | 20,000 | 22132.7 | 23313.3 | +1180.6 | 1.05x | 743.1 | 1073.7 |
| BuildCounter | 100 | 37423.5 | 33242.0 | -4181.5 | 0.89x | 1636.0 | 1535.1 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 751.9 | 2450.8 | +1698.8 | 3.26x | 25.7 | 93.4 |
| Get-64B | 64B | 100,000 | 104.5 | 790.0 | +685.5 | 7.56x | 2.9 | 21.9 |
| Transaction-64B | 64B | 400 | 6213.6 | 24154.1 | +17940.5 | 3.89x | 493.0 | 440.9 |
| SyncLocal-64B | 64B | 4,000 | 20653.8 | 23346.9 | +2693.2 | 1.13x | 1707.3 | 3006.8 |
| Set-1024B | 1024B | 400 | 1688.5 | 6607.5 | +4919.0 | 3.91x | 80.1 | 470.6 |
| Get-1024B | 1024B | 20,000 | 222.7 | 2491.5 | +2268.8 | 11.19x | 8.5 | 71.7 |
| Transaction-1024B | 1024B | 40 | 16091.6 | 71817.0 | +55725.4 | 4.46x | 483.2 | 3396.2 |
| SyncLocal-1024B | 1024B | 400 | 19659.9 | 25300.7 | +5640.8 | 1.29x | 818.5 | 966.5 |
| Set-16384B | 16384B | 40 | 16270.8 | 59004.4 | +42733.6 | 3.63x | 561.6 | 3456.2 |
| Get-16384B | 16384B | 2,000 | 2204.6 | 24988.2 | +22783.6 | 11.33x | 88.6 | 1314.0 |
| Transaction-16384B | 16384B | 4 | 181614.6 | 626667.6 | +445053.0 | 3.45x | 11691.6 | 49132.4 |
| SyncLocal-16384B | 16384B | 40 | 43452.8 | 86586.1 | +43133.3 | 1.99x | 1967.5 | 5611.8 |

