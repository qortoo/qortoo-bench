# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-23T23:55:33.584565+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `16e2c22c85d49c80f328cf11dd3136f67fe3a53a` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 281.2 | 352.6 | +71.3 | 1.25x | 6.9 | 29.4 |
| GetValue | 2,000,000 | 4.0 | 28.0 | +24.0 | 7.00x | 0.1 | 1.6 |
| Transaction | 20,000 | 1572.4 | 2938.8 | +1366.3 | 1.87x | 56.1 | 145.9 |
| SyncLocal | 20,000 | 19781.4 | 20484.1 | +702.7 | 1.04x | 1316.7 | 960.7 |
| BuildCounter | 100 | 35854.2 | 32354.2 | -3500.1 | 0.90x | 2616.2 | 3313.7 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 652.0 | 2469.6 | +1817.5 | 3.79x | 24.2 | 196.0 |
| Get-64B | 64B | 100,000 | 99.0 | 914.4 | +815.5 | 9.24x | 3.0 | 62.8 |
| Transaction-64B | 64B | 400 | 5035.7 | 22505.9 | +17470.2 | 4.47x | 95.0 | 1356.4 |
| SyncLocal-64B | 64B | 4,000 | 15729.0 | 19873.6 | +4144.6 | 1.26x | 3314.5 | 2322.7 |
| Set-1024B | 1024B | 400 | 1692.4 | 6477.4 | +4785.1 | 3.83x | 79.3 | 786.5 |
| Get-1024B | 1024B | 20,000 | 214.9 | 2880.4 | +2665.5 | 13.40x | 7.7 | 385.4 |
| Transaction-1024B | 1024B | 40 | 16336.2 | 70062.3 | +53726.1 | 4.29x | 731.6 | 8328.5 |
| SyncLocal-1024B | 1024B | 400 | 15111.5 | 21326.1 | +6214.5 | 1.41x | 2230.8 | 3082.3 |
| Set-16384B | 16384B | 40 | 18473.7 | 65254.1 | +46780.4 | 3.53x | 1164.7 | 10569.0 |
| Get-16384B | 16384B | 2,000 | 2116.0 | 29408.1 | +27292.0 | 13.90x | 73.8 | 1823.1 |
| Transaction-16384B | 16384B | 4 | 198203.5 | 655611.5 | +457408.0 | 3.31x | 8433.1 | 54164.6 |
| SyncLocal-16384B | 16384B | 40 | 36973.8 | 83299.6 | +46325.8 | 2.25x | 3121.9 | 4227.8 |

