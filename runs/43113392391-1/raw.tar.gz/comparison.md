# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-11T22:42:35.225407+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 442.7 | 565.9 | +123.2 | 1.28x | 52.5 | 67.7 |
| GetValue | 2,000,000 | 5.4 | 45.7 | +40.3 | 8.47x | 4.2 | 4.9 |
| Transaction | 20,000 | 2129.4 | 4923.6 | +2794.3 | 2.31x | 476.0 | 1060.8 |
| SyncLocal | 20,000 | 29019.1 | 31382.8 | +2363.6 | 1.08x | 1373.5 | 1059.6 |
| BuildCounter | 100 | 62799.8 | 53806.8 | -8993.0 | 0.86x | 23643.9 | 17476.0 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1286.1 | 3255.3 | +1969.3 | 2.53x | 485.4 | 738.4 |
| Get-64B | 64B | 100,000 | 153.9 | 1833.9 | +1680.0 | 11.91x | 79.3 | 447.3 |
| Transaction-64B | 64B | 400 | 16793.5 | 66825.9 | +50032.4 | 3.98x | 4726.6 | 11951.4 |
| SyncLocal-64B | 64B | 4,000 | 34067.8 | 36491.3 | +2423.5 | 1.07x | 4843.7 | 5214.9 |
| Set-1024B | 1024B | 400 | 2439.9 | 10369.3 | +7929.4 | 4.25x | 1144.9 | 3717.2 |
| Get-1024B | 1024B | 20,000 | 288.6 | 4210.4 | +3921.8 | 14.59x | 119.3 | 1272.9 |
| Transaction-1024B | 1024B | 40 | 33258.8 | 156205.1 | +122946.3 | 4.70x | 12253.9 | 44078.6 |
| SyncLocal-1024B | 1024B | 400 | 38461.9 | 45620.0 | +7158.1 | 1.19x | 10950.4 | 12385.8 |
| Set-16384B | 16384B | 40 | 26841.4 | 105129.5 | +78288.1 | 3.92x | 14550.4 | 43862.3 |
| Get-16384B | 16384B | 2,000 | 5692.2 | 63453.4 | +57761.2 | 11.15x | 1702.4 | 13765.7 |
| Transaction-16384B | 16384B | 4 | 661811.5 | 2062746.2 | +1400934.8 | 3.12x | 163991.7 | 453477.2 |
| SyncLocal-16384B | 16384B | 40 | 107532.5 | 260909.5 | +153377.0 | 2.43x | 26468.0 | 49494.9 |

