# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-28T13:45:07.223400+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `69469e18b57a951cba371c13de6ab6dd27fb34c7` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 399.5 | 491.1 | +91.6 | 1.23x | 67.4 | 46.9 |
| GetValue | 2,000,000 | 13.5 | 38.1 | +24.5 | 2.81x | 3.9 | 4.4 |
| Transaction | 20,000 | 2996.5 | 4765.9 | +1769.4 | 1.59x | 538.5 | 801.7 |
| SyncLocal | 20,000 | 30027.8 | 32465.9 | +2438.2 | 1.08x | 2083.4 | 4278.7 |
| BuildCounter | 100 | 69184.3 | 60097.2 | -9087.1 | 0.87x | 11719.3 | 13444.9 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 909.3 | 4025.2 | +3116.0 | 4.43x | 397.1 | 1264.0 |
| Get-64B | 64B | 100,000 | 129.0 | 1566.9 | +1437.8 | 12.14x | 71.7 | 263.7 |
| Transaction-64B | 64B | 400 | 10307.0 | 51061.7 | +40754.6 | 4.95x | 4765.2 | 13768.4 |
| SyncLocal-64B | 64B | 4,000 | 33096.9 | 35223.6 | +2126.7 | 1.06x | 5178.8 | 6655.3 |
| Set-1024B | 1024B | 400 | 3466.5 | 9129.8 | +5663.3 | 2.63x | 1666.4 | 4863.0 |
| Get-1024B | 1024B | 20,000 | 681.8 | 5972.0 | +5290.2 | 8.76x | 178.7 | 1078.2 |
| Transaction-1024B | 1024B | 40 | 22772.0 | 116398.3 | +93626.3 | 5.11x | 15211.2 | 50540.5 |
| SyncLocal-1024B | 1024B | 400 | 39073.3 | 52372.6 | +13299.3 | 1.34x | 10756.0 | 13037.9 |
| Set-16384B | 16384B | 40 | 33073.0 | 144836.5 | +111763.4 | 4.38x | 19334.5 | 47368.8 |
| Get-16384B | 16384B | 2,000 | 3358.8 | 53981.2 | +50622.4 | 16.07x | 2182.1 | 17308.5 |
| Transaction-16384B | 16384B | 4 | 312358.9 | 1653331.8 | +1340972.9 | 5.29x | 192639.4 | 693251.2 |
| SyncLocal-16384B | 16384B | 40 | 56490.2 | 198011.7 | +141521.5 | 3.51x | 38998.1 | 61613.1 |

