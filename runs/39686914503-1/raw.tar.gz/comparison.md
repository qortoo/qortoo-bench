# Same-Host Benchmark Comparison Report

- **Date**: 2026-10-21T22:34:30.632978+00:00
- **Platform**: `Linux-7.0.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `e849a4eff55bc1cb03b28b5a5078f4ae73d85015` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 429.6 | 627.7 | +198.1 | 1.46x | 8.8 | 37.9 |
| GetValue | 2,000,000 | 6.7 | 41.6 | +34.9 | 6.21x | 0.1 | 0.6 |
| Transaction | 20,000 | 2423.8 | 4702.6 | +2278.7 | 1.94x | 58.1 | 120.9 |
| SyncLocal | 20,000 | 26710.2 | 29367.2 | +2657.0 | 1.10x | 1051.3 | 770.4 |
| BuildCounter | 100 | 60444.9 | 57699.2 | -2745.7 | 0.95x | 1338.9 | 641.4 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 1009.8 | 4549.2 | +3539.5 | 4.51x | 94.1 | 97.6 |
| Get-64B | 64B | 100,000 | 146.6 | 1373.6 | +1227.0 | 9.37x | 12.9 | 8.7 |
| Transaction-64B | 64B | 400 | 8242.1 | 45980.3 | +37738.2 | 5.58x | 127.0 | 1413.3 |
| SyncLocal-64B | 64B | 4,000 | 23953.7 | 32100.3 | +8146.6 | 1.34x | 1228.1 | 1127.7 |
| Set-1024B | 1024B | 400 | 2501.1 | 15501.3 | +13000.2 | 6.20x | 70.6 | 1580.5 |
| Get-1024B | 1024B | 20,000 | 338.4 | 4079.7 | +3741.3 | 12.06x | 2.7 | 66.4 |
| Transaction-1024B | 1024B | 40 | 23769.4 | 161533.9 | +137764.5 | 6.80x | 514.1 | 4651.0 |
| SyncLocal-1024B | 1024B | 400 | 25402.8 | 44371.4 | +18968.6 | 1.75x | 599.3 | 1633.4 |
| Set-16384B | 16384B | 40 | 27539.5 | 135109.4 | +107569.9 | 4.91x | 1144.5 | 4905.6 |
| Get-16384B | 16384B | 2,000 | 3234.1 | 40700.9 | +37466.8 | 12.58x | 1181.7 | 1017.6 |
| Transaction-16384B | 16384B | 4 | 298653.6 | 1451512.0 | +1152858.4 | 4.86x | 7089.7 | 48337.7 |
| SyncLocal-16384B | 16384B | 40 | 55632.3 | 176007.7 | +120375.4 | 3.16x | 1232.5 | 4883.7 |

