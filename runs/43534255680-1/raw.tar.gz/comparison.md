# Same-Host Benchmark Comparison Report

- **Date**: 2026-11-14T00:31:16.369162+00:00
- **Platform**: `Linux-6.14.0-1017-azure-x86_64-with-glibc2.39`
- **Rust Toolchain**: `rustc 1.97.1 (8bab26f4f 2026-07-14)`
- **Go Toolchain**: `go version go1.27.2 linux/amd64`
- **Harness SHA**: `3444d989e2f1b2e168c25f1cf5b77b6f5918b917` (dirty: `False`)
- **Rounds**: 10 measured rounds (1 discarded warmup) with interleaved execution order per round to mitigate host condition drift

## Measurement Interpretation & Contract

> [!NOTE]
> Latency values are reported in `ns/op` where smaller numbers represent better performance.
> Observed differences reflect the total path of the public API calls (including serialization, FFI, and runtime interactions),
> not a pure CGO invocation overhead.
> Go runtime allocations and Rust native heap allocations are not measured or reported by this latency harness (latency only).

## Suite: `counter` (`counter/v1`)

| Scenario | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| IncreaseBy | 200,000 | 384.9 | 502.3 | +117.4 | 1.31x | 37.9 | 41.3 |
| GetValue | 2,000,000 | 5.5 | 37.0 | +31.6 | 6.78x | 3.4 | 5.8 |
| Transaction | 20,000 | 2038.0 | 4100.4 | +2062.4 | 2.01x | 287.4 | 1175.3 |
| SyncLocal | 20,000 | 27764.7 | 34109.7 | +6345.0 | 1.23x | 1314.6 | 5627.2 |
| BuildCounter | 100 | 63390.0 | 59844.3 | -3545.7 | 0.94x | 78952.8 | 44257.9 |

## Suite: `variable` (`variable/v1`)

| Scenario | Payload | Budget | Rust Median (ns/op) | Go Median (ns/op) | Diff (Go - Rust) | Ratio (Go / Rust) | Rust StdDev | Go StdDev |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Set-64B | 64B | 4,000 | 911.7 | 3256.1 | +2344.5 | 3.57x | 261.4 | 449.5 |
| Get-64B | 64B | 100,000 | 153.8 | 1315.3 | +1161.5 | 8.55x | 75.4 | 333.9 |
| Transaction-64B | 64B | 400 | 7520.5 | 35283.5 | +27763.0 | 4.69x | 3219.5 | 11377.6 |
| SyncLocal-64B | 64B | 4,000 | 26787.0 | 36874.0 | +10087.0 | 1.38x | 8433.2 | 17657.4 |
| Set-1024B | 1024B | 400 | 2712.9 | 11581.8 | +8869.0 | 4.27x | 1562.5 | 3836.5 |
| Get-1024B | 1024B | 20,000 | 291.8 | 4862.7 | +4570.9 | 16.67x | 116.2 | 599.8 |
| Transaction-1024B | 1024B | 40 | 25654.9 | 146302.5 | +120647.6 | 5.70x | 6892.5 | 41507.5 |
| SyncLocal-1024B | 1024B | 400 | 22720.5 | 41642.4 | +18921.9 | 1.83x | 9585.0 | 9980.9 |
| Set-16384B | 16384B | 40 | 28348.3 | 137529.7 | +109181.4 | 4.85x | 12184.5 | 29634.8 |
| Get-16384B | 16384B | 2,000 | 2945.3 | 61252.8 | +58307.5 | 20.80x | 1469.1 | 11858.3 |
| Transaction-16384B | 16384B | 4 | 323398.1 | 1347367.9 | +1023969.8 | 4.17x | 153116.5 | 519797.5 |
| SyncLocal-16384B | 16384B | 40 | 64978.6 | 170245.0 | +105266.4 | 2.62x | 44307.6 | 41004.6 |

